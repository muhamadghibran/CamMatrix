"""add is_public column to cameras (N1 fix)

Revision ID: p5fix_is_public
Revises: <PREVIOUS_HEAD>
Create Date: 2026-04-27

NOTE: revisi `down_revision` ke head terakhir di repo magang.
Cek dengan: alembic heads
"""
from alembic import op
import sqlalchemy as sa


revision = "p5fix_is_public"
down_revision = None  # ← GANTI ke head terakhir setelah jalankan `alembic heads`
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "cameras",
        sa.Column(
            "is_public",
            sa.Boolean(),
            server_default=sa.text("false"),
            nullable=False,
        ),
    )
    op.create_index("ix_cameras_is_public", "cameras", ["is_public"])


def downgrade() -> None:
    op.drop_index("ix_cameras_is_public", table_name="cameras")
    op.drop_column("cameras", "is_public")
