"""
Endpoint publik — tidak memerlukan autentikasi.

N1 FIX: Hanya kamera dengan is_public=true yang dikembalikan.
Operator harus opt-in eksplisit per kamera (kolom baru di Module 04).
"""
from typing import Any
import asyncio
from fastapi import APIRouter
from sqlalchemy import select

from app.api import deps
from app.models.camera import Camera
from app.core.config import settings
from app.api.v1.endpoints.cameras import _path_name, get_mediamtx_status

router = APIRouter()

HLS_BASE = settings.HLS_BASE_URL


@router.get("/cameras", tags=["public"])
async def public_cameras(db: deps.DbSession) -> Any:
    """
    Daftar kamera PUBLIK (is_public=true).
    TIDAK memerlukan login. TIDAK mengembalikan credentials.
    Hanya nama, lokasi, dan stream_url HLS.
    """
    # N1 FIX: filter is_public=true, default-deny
    result = await db.execute(
        select(Camera).where(Camera.is_public == True)  # noqa: E712
    )
    cameras = result.scalars().all()

    if not cameras:
        return []

    statuses = await asyncio.gather(
        *[get_mediamtx_status(cam.owner_id, cam.id) for cam in cameras]
    )

    return [
        {
            "id": cam.id,
            "name": cam.name,
            "location": cam.location or "",
            "status": st,
            "stream_url": f"{HLS_BASE}/{_path_name(cam.owner_id, cam.id)}/index.m3u8",
        }
        for cam, st in zip(cameras, statuses)
    ]
