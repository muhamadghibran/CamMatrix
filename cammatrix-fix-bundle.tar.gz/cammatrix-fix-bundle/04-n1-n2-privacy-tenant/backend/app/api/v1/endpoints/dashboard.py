"""
Endpoint dashboard — data real dari database dan MediaMTX.

N2 FIX: scope per-owner kecuali admin. Operator A tidak boleh enumerate
properti/lokasi/nama kamera operator B.
"""
from typing import Any
import asyncio
import httpx
from fastapi import APIRouter, Depends
from sqlalchemy import select, func

from app.api import deps
from app.models.camera import Camera
from app.models.recording import Recording
from app.models.user import User, UserRole
from app.core.config import settings
from app.api.v1.endpoints.cameras import _path_name

router = APIRouter()

MEDIAMTX_API = settings.MEDIAMTX_API_URL


async def _check_cam_live(owner_id: int, cam_id: int) -> bool:
    try:
        path = _path_name(owner_id, cam_id)
        async with httpx.AsyncClient(timeout=2.0) as client:
            res = await client.get(f"{MEDIAMTX_API}/v3/paths/get/{path}")
            if res.status_code == 200:
                data = res.json()
                return bool(data.get("sourceReady") or data.get("ready"))
    except Exception:
        pass
    return False


def _scope_camera_query(stmt, current_user: User):
    """Helper N2 FIX: filter Camera by owner kecuali admin."""
    if current_user.role != UserRole.ADMIN:
        stmt = stmt.where(Camera.owner_id == current_user.id)
    return stmt


@router.get("/stats")
async def dashboard_stats(
    db: deps.DbSession,
    current_user: User = Depends(deps.get_current_user_full_scope),  # P4 + N2
) -> Any:
    """
    Statistik dashboard scoped per-owner.
    ADMIN melihat global; user biasa hanya kamera + rekamannya sendiri.
    """
    # ── Kamera ──────────────────────────────────────────────
    cam_stmt = _scope_camera_query(select(Camera), current_user)
    cam_result = await db.execute(cam_stmt)
    cameras = cam_result.scalars().all()

    live_statuses = await asyncio.gather(
        *[_check_cam_live(cam.owner_id, cam.id) for cam in cameras]
    )

    total_cameras = len(cameras)
    live_count = sum(live_statuses)
    offline_count = total_cameras - live_count

    # ── Rekaman ─────────────────────────────────────────────
    rec_stmt = select(func.count(Recording.id))
    if current_user.role != UserRole.ADMIN:
        # JOIN cameras untuk filter by owner
        rec_stmt = (
            select(func.count(Recording.id))
            .join(Camera, Camera.id == Recording.camera_id)
            .where(Camera.owner_id == current_user.id)
        )
    rec_result = await db.execute(rec_stmt)
    total_recordings = rec_result.scalar() or 0

    # ── Storage ─────────────────────────────────────────────
    size_stmt = select(func.sum(Recording.size_bytes))
    if current_user.role != UserRole.ADMIN:
        size_stmt = (
            select(func.sum(Recording.size_bytes))
            .join(Camera, Camera.id == Recording.camera_id)
            .where(Camera.owner_id == current_user.id)
        )
    size_result = await db.execute(size_stmt)
    total_bytes = size_result.scalar() or 0
    storage_gb = round(total_bytes / (1024 ** 3), 2)

    # ── Active users (admin only — non-admin tidak butuh tahu) ─
    active_users = None
    if current_user.role == UserRole.ADMIN:
        user_result = await db.execute(
            select(func.count(User.id)).where(User.is_active == True)  # noqa: E712
        )
        active_users = user_result.scalar() or 0

    response = {
        "total_cameras": total_cameras,
        "live_cameras": live_count,
        "offline_cameras": offline_count,
        "total_recordings": total_recordings,
        "storage_gb": storage_gb,
    }
    if active_users is not None:
        response["active_users"] = active_users
    return response


@router.get("/cameras-status")
async def cameras_status(
    db: deps.DbSession,
    current_user: User = Depends(deps.get_current_user_full_scope),  # P4 + N2
) -> Any:
    """
    Status real per-kamera, scoped per-owner.
    """
    stmt = _scope_camera_query(select(Camera), current_user)
    cam_result = await db.execute(stmt)
    cameras = cam_result.scalars().all()

    if not cameras:
        return []

    live_statuses = await asyncio.gather(
        *[_check_cam_live(cam.owner_id, cam.id) for cam in cameras]
    )

    return [
        {
            "id": cam.id,
            "name": cam.name,
            "location": cam.location or "",
            "status": "live" if is_live else "offline",
        }
        for cam, is_live in zip(cameras, live_statuses)
    ]
