#!/bin/bash
# Module 04: N1 + N2 — privacy default-closed + dashboard cross-tenant fix
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/CamMatrix}"
BACKEND_DIR="${BACKEND_DIR:-${APP_DIR}/backend}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/cammatrix-fix-p5}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok() { echo -e "${GREEN}✓ $*${NC}"; }
err() { echo -e "${RED}✗ $*${NC}" >&2; }
warn() { echo -e "${YELLOW}! $*${NC}"; }

[ "$EUID" -eq 0 ] || { err "Harus sudo"; exit 1; }

mkdir -p "$BACKUP_DIR"
TS=$(date +%Y%m%d-%H%M%S)
BACKEND_USER=$(systemctl show cammatrix-backend -p User --value 2>/dev/null || echo "root")
[ -z "$BACKEND_USER" ] && BACKEND_USER="root"

# ── 1. Backup files yang akan diubah ──────────────────────────────────
for rel in app/models/camera.py app/api/v1/endpoints/public.py app/api/v1/endpoints/dashboard.py; do
    src="$BACKEND_DIR/$rel"
    if [ -f "$src" ]; then
        flat=$(echo "$rel" | tr / _)
        cp -p "$src" "$BACKUP_DIR/${flat}.bak-$TS"
        ok "Backup $rel"
    fi
done

# ── 2. Cek alembic head ────────────────────────────────────────────────
echo
echo "=== Alembic head check ==="
cd "$BACKEND_DIR"
CURRENT_HEAD=$(sudo -u "$BACKEND_USER" "$BACKEND_DIR/venv/bin/alembic" heads 2>/dev/null | awk '{print $1}' | head -1)
if [ -z "$CURRENT_HEAD" ]; then
    err "Tidak bisa baca alembic heads. Pastikan alembic terinstal + DATABASE_URL valid."
    exit 1
fi
ok "Current head: $CURRENT_HEAD"

# Patch revision ID di template migration
MIGRATION_SRC="$SCRIPT_DIR/backend/alembic/versions/p5fix_add_is_public_to_cameras.py"
MIGRATION_DST="$BACKEND_DIR/alembic/versions/$(date +%Y%m%d%H%M%S)_p5fix_is_public.py"

sed "s|down_revision = None  # ← GANTI ke head terakhir setelah jalankan \`alembic heads\`|down_revision = \"$CURRENT_HEAD\"|" \
    "$MIGRATION_SRC" > "$MIGRATION_DST"
chown "$BACKEND_USER:$BACKEND_USER" "$MIGRATION_DST" 2>/dev/null || chown root:root "$MIGRATION_DST"
ok "Migration ditulis: $MIGRATION_DST (down_revision=$CURRENT_HEAD)"

# ── 3. Replace model + endpoints ──────────────────────────────────────
ORIG_OWNER=$(stat -c "%U:%G" "$BACKEND_DIR/main.py")

cp "$SCRIPT_DIR/backend/app/models/camera.py" "$BACKEND_DIR/app/models/camera.py"
chown "$ORIG_OWNER" "$BACKEND_DIR/app/models/camera.py"
ok "Replaced models/camera.py (tambah is_public column)"

cp "$SCRIPT_DIR/backend/app/api/v1/endpoints/public.py" "$BACKEND_DIR/app/api/v1/endpoints/public.py"
chown "$ORIG_OWNER" "$BACKEND_DIR/app/api/v1/endpoints/public.py"
ok "Replaced endpoints/public.py (filter is_public)"

cp "$SCRIPT_DIR/backend/app/api/v1/endpoints/dashboard.py" "$BACKEND_DIR/app/api/v1/endpoints/dashboard.py"
chown "$ORIG_OWNER" "$BACKEND_DIR/app/api/v1/endpoints/dashboard.py"
ok "Replaced endpoints/dashboard.py (scope per-owner)"

# Syntax check semua
for f in "$BACKEND_DIR/app/models/camera.py" "$BACKEND_DIR/app/api/v1/endpoints/public.py" "$BACKEND_DIR/app/api/v1/endpoints/dashboard.py"; do
    "$BACKEND_DIR/venv/bin/python" -c "import ast; ast.parse(open('$f').read())" || {
        err "Syntax error di $f"
        exit 1
    }
done
ok "Syntax check semua file passed"

# ── 4. Run migration ──────────────────────────────────────────────────
echo
echo "=== Run migration ==="
sudo -u "$BACKEND_USER" "$BACKEND_DIR/venv/bin/alembic" upgrade head 2>&1 | tail -10 || {
    err "Migration gagal. Restore: sudo -u $BACKEND_USER $BACKEND_DIR/venv/bin/alembic downgrade -1"
    exit 1
}
ok "Migration applied"

# ── 5. PERINGATAN: kamera EXISTING semua jadi non-public ──────────────
echo
warn "PENTING: SEMUA kamera existing sekarang is_public=false (default)."
warn "Halaman publik /live akan kosong sampai admin set is_public=true per kamera."
warn "Untuk migrasi cepat, set semua kamera milik admin@vms.com jadi public:"
echo
echo "  sudo -u postgres psql cctv_vms -c \"UPDATE cameras SET is_public=true WHERE owner_id=2;\""
echo

# ── 6. Update CameraCreate schema (kalau perlu) ────────────────────────
echo
echo "=== Cek CameraCreate schema ==="
SCHEMA_FILE="$BACKEND_DIR/app/schemas/camera.py"
if [ -f "$SCHEMA_FILE" ]; then
    if ! grep -q "is_public" "$SCHEMA_FILE"; then
        warn "$SCHEMA_FILE belum punya field is_public."
        warn "Tambah manual di CameraCreate / CameraUpdate / CameraResponse:"
        echo "    is_public: bool = False"
    else
        ok "schemas/camera.py sudah punya is_public"
    fi
fi

# ── 7. Restart backend ────────────────────────────────────────────────
echo
echo "=== Restart backend ==="
systemctl restart cammatrix-backend
sleep 2
if systemctl is-active cammatrix-backend >/dev/null 2>&1; then
    ok "cammatrix-backend running"
else
    err "Backend gagal start. Check log."
    exit 1
fi

echo
echo "=== Selesai ==="
cat <<EOF

Module 04 applied. Yang berubah:
  - Kolom is_public ditambah ke tabel cameras (default false)
  - GET /api/v1/public/cameras → hanya return is_public=true
  - GET /api/v1/dashboard/* → scoped per-owner kecuali admin

Backup: $BACKUP_DIR/

TODO MAGANG:
  1. Update frontend Add Camera form: tambah toggle "Tampilkan di halaman publik (is_public)"
  2. Update CameraCreate/Update/Response Pydantic schemas (lihat warning di atas)
  3. Migrasi data: SET is_public=true untuk kamera yang memang harus publik
EOF
