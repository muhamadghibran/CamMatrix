# Module 04 — N1 + N2: Privacy Default-Closed + Cross-Tenant Fix

## Masalah

### N1 — `/public/cameras` expose SEMUA kamera tanpa opt-in
`backend/app/api/v1/endpoints/public.py:21-44` — `select(Camera)` tanpa filter. Setiap kamera yang ditambahkan user manapun otomatis publik. Privacy violation by-default.

### N2 — Dashboard cross-tenant leak
`backend/app/api/v1/endpoints/dashboard.py:39-57,80-105` — `select(Camera)` tanpa filter owner. Operator A bisa lihat nama+lokasi+status kamera operator B (horizontal privilege escalation, reconnaissance untuk attack fisik).

## Fix

### N1 — kolom `is_public` opt-in
- Tambah kolom `is_public BOOLEAN NOT NULL DEFAULT FALSE` di tabel `cameras`
- `GET /public/cameras` filter `WHERE is_public = true`
- Default deny — kamera baru tidak otomatis publik

### N2 — scope query per-owner di dashboard
- `dashboard_stats` + `cameras-status` cek `current_user.role`
- Non-admin: filter `WHERE owner_id = current_user.id`
- Admin: lihat global
- Field `active_users` HANYA di-return untuk admin

## Cara apply

```bash
sudo ./apply.sh
```

Apply script:
1. Backup model + endpoints
2. Auto-detect alembic head, generate migration dengan `down_revision` yang tepat
3. Replace `app/models/camera.py` dengan versi yang punya `is_public`
4. Replace `app/api/v1/endpoints/public.py` (filter `is_public`)
5. Replace `app/api/v1/endpoints/dashboard.py` (scope per-owner + pakai `get_current_user_full_scope` dari Module 01)
6. Run `alembic upgrade head`
7. Restart backend

## ⚠️ Konsekuensi data: halaman publik akan kosong

Setelah apply:
- Semua kamera existing default `is_public=false`
- `GET /public/cameras` return `[]`
- Halaman `/live` di frontend akan tampil "Tidak ada kamera publik"

**Untuk migrasi cepat** (kalau memang semua kamera lab harus publik):
```bash
sudo -u postgres psql cctv_vms -c "UPDATE cameras SET is_public=true WHERE owner_id=2;"
# (ganti owner_id dengan ID admin yang relevant)
```

Atau via API:
```bash
TOKEN=...  # admin token
curl -X PUT http://server:8000/api/v1/cameras/16 \
     -H "Authorization: Bearer $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"is_public": true}'
```

## TODO magang lanjutan

### 1. Update Pydantic schemas
`backend/app/schemas/camera.py` perlu tambah field `is_public`. Apply script print warning kalau belum ada. Edit manual:

```python
class CameraCreate(BaseModel):
    name: str
    location: str | None = None
    rtsp_url: str
    username: str | None = None
    password: str | None = None
    is_public: bool = False              # ← TAMBAH

class CameraUpdate(BaseModel):
    name: str | None = None
    location: str | None = None
    rtsp_url: str | None = None
    username: str | None = None
    password: str | None = None
    is_public: bool | None = None        # ← TAMBAH

class CameraResponse(BaseModel):
    # ... field existing ...
    is_public: bool                      # ← TAMBAH
```

### 2. Update `cameras.py` endpoint POST/PUT
Pastikan `create_camera` dan `update_camera` baca field `is_public` dari payload dan pass ke model. Karena Camera model sudah punya field, tinggal tambah di code yang construct/update Camera object.

### 3. Frontend — toggle di Add/Edit Camera form
Tambah checkbox "Tampilkan di halaman publik" di form. Default off. Bantuan UI: "Kamera dengan toggle ini ON akan terlihat di halaman /live tanpa login."

### 4. `camera_to_dict` di `cameras.py` Module 00 (P5)
Sudah di-update di Module 00 untuk return `password: ""`. Tambah juga `is_public: cam.is_public` supaya frontend tahu state-nya.

## Verifikasi

```bash
# 1. Kolom is_public ada
sudo -u postgres psql cctv_vms -c "\d cameras" | grep is_public

# 2. Public endpoint return [] (semua kamera default false)
curl http://localhost:8000/api/v1/public/cameras
# Expected: []

# 3. Dashboard sebagai non-admin → lihat 0 kamera (kalau dia bukan owner)
# 4. Dashboard sebagai admin → lihat semua

# 5. Set 1 kamera jadi public, verifikasi muncul
sudo -u postgres psql cctv_vms -c "UPDATE cameras SET is_public=true WHERE id=16;"
curl http://localhost:8000/api/v1/public/cameras | python3 -m json.tool
# Expected: 1 kamera muncul
```

## Rollback

```bash
ls -lt /var/backups/cammatrix-fix-p5/app_*.bak-* | head -3
# Restore file
sudo cp /var/backups/cammatrix-fix-p5/app_models_camera.py.bak-<TS> /var/www/CamMatrix/backend/app/models/camera.py
sudo cp /var/backups/cammatrix-fix-p5/app_api_v1_endpoints_public.py.bak-<TS> /var/www/CamMatrix/backend/app/api/v1/endpoints/public.py
sudo cp /var/backups/cammatrix-fix-p5/app_api_v1_endpoints_dashboard.py.bak-<TS> /var/www/CamMatrix/backend/app/api/v1/endpoints/dashboard.py

# Rollback migration
cd /var/www/CamMatrix/backend
sudo -u root ./venv/bin/alembic downgrade -1

sudo systemctl restart cammatrix-backend
```
