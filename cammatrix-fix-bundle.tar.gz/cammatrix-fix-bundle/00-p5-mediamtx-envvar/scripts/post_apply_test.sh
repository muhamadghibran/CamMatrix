#!/bin/bash
# Post-apply smoke test — jalankan setelah apply.sh untuk verifikasi cepat.
set -uo pipefail

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASS=0
FAIL=0

check() {
    local name="$1"
    local cmd="$2"
    if eval "$cmd" >/dev/null 2>&1; then
        echo -e "  ${GREEN}✓${NC} $name"
        PASS=$((PASS+1))
    else
        echo -e "  ${RED}✗${NC} $name"
        FAIL=$((FAIL+1))
    fi
}

echo "═══ Post-Apply Smoke Test ═══"
echo

echo "[Service]"
check "cammatrix-backend active" "systemctl is-active cammatrix-backend"
check "mediamtx active"          "systemctl is-active mediamtx"
check "postgresql active"        "systemctl is-active postgresql"
echo

echo "[MediaMTX health]"
check "API :9997 responds"       "curl -fsS --max-time 3 http://127.0.0.1:9997/v3/paths/list"
check "RTSP :8554 listens"       "ss -tln | grep -q ':8554 '"
check "HLS :8888 listens"        "ss -tln | grep -q ':8888 '"
echo

echo "[Backend health]"
check "API :8000 responds"       "curl -fsS --max-time 3 -o /dev/null http://127.0.0.1:8000/api/v1/public/cameras"
echo

echo "[Patch verification]"
check "No env-var pattern in cameras.py" \
    '! grep -q "source: \${CAM_" /var/www/CamMatrix/backend/app/api/v1/endpoints/cameras.py'
check "No env-var pattern in mediamtx.yml" \
    '! sudo grep -q "\${CAM_" /etc/mediamtx/mediamtx.yml'
check "mediamtx.yml mode 600"    "[ \"\$(stat -c %a /etc/mediamtx/mediamtx.yml)\" = \"600\" ]"
echo

echo "[MediaMTX stability — 10s window]"
NRESTART_BEFORE=$(systemctl show mediamtx -p NRestarts --value 2>/dev/null || echo 0)
sleep 10
NRESTART_AFTER=$(systemctl show mediamtx -p NRestarts --value 2>/dev/null || echo 0)
DIFF=$((NRESTART_AFTER - NRESTART_BEFORE))

if [ "$DIFF" -eq 0 ]; then
    echo -e "  ${GREEN}✓${NC} No restart in 10s (stable)"
    PASS=$((PASS+1))
else
    echo -e "  ${RED}✗${NC} $DIFF restart in 10s (still crashing)"
    FAIL=$((FAIL+1))
fi

echo
echo "═══════════════════════════════════════════"
echo "  PASS: $PASS  |  FAIL: $FAIL"
echo "═══════════════════════════════════════════"

if [ "$FAIL" -eq 0 ]; then
    echo -e "  ${GREEN}All checks passed. Patch sukses.${NC}"
    exit 0
else
    echo -e "  ${RED}Ada kegagalan. Cek log:${NC}"
    echo "    journalctl -u mediamtx -n 30 --no-pager"
    echo "    journalctl -u cammatrix-backend -n 30 --no-pager"
    exit 1
fi
