#!/bin/bash
# Test end-to-end: add kamera RTSP via API + verify HLS stream playable
# Default URL kamera: rtsp://192.168.28.6/user=admin&password=PJN03030362&channel=2&stream=0.sdp
#
# Usage:
#   ./test_add_camera_pjn.sh
#   ADMIN_EMAIL=foo@bar.com ADMIN_PASSWORD=secret ./test_add_camera_pjn.sh
#   CAMERA_RTSP="rtsp://other-host/stream" ./test_add_camera_pjn.sh
#
# Script ini DELETE kamera test setelah verifikasi (kecuali KEEP=1).

set -uo pipefail

# ───────────────────────────────────────────────────────────────
# Config
# ───────────────────────────────────────────────────────────────
API_BASE="${API_BASE:-http://127.0.0.1:8000/api/v1}"
HLS_BASE="${HLS_BASE:-http://127.0.0.1:8888}"
CAMERA_RTSP="${CAMERA_RTSP:-rtsp://192.168.28.6/user=admin&password=PJN03030362&channel=2&stream=0.sdp}"
CAMERA_NAME="${CAMERA_NAME:-TestPJN-$(date +%s)}"
KEEP="${KEEP:-0}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'
err()  { echo -e "${RED}✗ $*${NC}" >&2; }
ok()   { echo -e "${GREEN}✓ $*${NC}"; }
warn() { echo -e "${YELLOW}! $*${NC}"; }
hdr()  { echo; echo "=== $* ==="; }

# Need: jq, curl
for cmd in curl python3; do
    command -v $cmd >/dev/null 2>&1 || { err "Butuh $cmd di PATH"; exit 1; }
done

# ───────────────────────────────────────────────────────────────
# Login
# ───────────────────────────────────────────────────────────────
hdr "Login API"

if [ -z "${ADMIN_EMAIL:-}" ]; then
    read -p "Admin email: " ADMIN_EMAIL
fi
if [ -z "${ADMIN_PASSWORD:-}" ]; then
    read -s -p "Admin password: " ADMIN_PASSWORD
    echo
fi

LOGIN_RESP=$(curl -sS -X POST "$API_BASE/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "username=$ADMIN_EMAIL" \
    --data-urlencode "password=$ADMIN_PASSWORD")

TOKEN=$(echo "$LOGIN_RESP" | python3 -c 'import sys,json;d=json.load(sys.stdin);print(d.get("access_token",""))')

if [ -z "$TOKEN" ]; then
    err "Login gagal. Response: $LOGIN_RESP"
    exit 1
fi
ok "Login OK (token len ${#TOKEN})"

# ───────────────────────────────────────────────────────────────
# Pre-flight: MediaMTX up?
# ───────────────────────────────────────────────────────────────
hdr "Pre-flight"

if ! curl -fsS --max-time 3 http://127.0.0.1:9997/v3/paths/list >/dev/null 2>&1; then
    warn "MediaMTX API :9997 tidak respond. Stream test akan gagal."
    warn "Pastikan MediaMTX running: sudo systemctl status mediamtx"
fi
ok "Pre-flight OK"

# ───────────────────────────────────────────────────────────────
# Add camera
# ───────────────────────────────────────────────────────────────
hdr "POST /cameras/"

PAYLOAD=$(python3 -c "
import json
print(json.dumps({
    'name': '$CAMERA_NAME',
    'location': 'Test add via script',
    'rtsp_url': '''$CAMERA_RTSP''',
}))")

ADD_RESP=$(curl -sS -L -w "\n__HTTP_CODE__:%{http_code}" -X POST "$API_BASE/cameras/" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "$PAYLOAD")

HTTP_CODE=$(echo "$ADD_RESP" | tail -1 | sed 's/__HTTP_CODE__://')
BODY=$(echo "$ADD_RESP" | sed '$ d')

if [ "$HTTP_CODE" != "201" ]; then
    err "POST gagal HTTP $HTTP_CODE"
    err "Body: $BODY"
    exit 1
fi
ok "POST sukses HTTP 201"

CAM_ID=$(echo "$BODY" | python3 -c 'import sys,json;print(json.load(sys.stdin)["id"])')
STREAM_URL=$(echo "$BODY" | python3 -c 'import sys,json;print(json.load(sys.stdin)["stream_url"])')
SLUG=$(echo "$STREAM_URL" | sed 's|.*/\(cam_[0-9]*_[0-9]*\)/.*|\1|')

ok "Camera ID  : $CAM_ID"
ok "Camera slug: $SLUG"
ok "Stream URL : $STREAM_URL"

# ───────────────────────────────────────────────────────────────
# Verify MediaMTX picked up the path
# ───────────────────────────────────────────────────────────────
hdr "Verify MediaMTX path"

sleep 2
PATH_INFO=$(curl -sS "http://127.0.0.1:9997/v3/paths/get/$SLUG" 2>/dev/null || echo '{}')
READY=$(echo "$PATH_INFO" | python3 -c 'import sys,json
try:
    d=json.load(sys.stdin)
    print(d.get("ready", d.get("sourceReady", False)))
except: print("error")')

if [ "$READY" = "True" ]; then
    ok "MediaMTX path ready"
else
    warn "MediaMTX path belum ready (mungkin butuh beberapa detik lagi)"
    echo "$PATH_INFO" | python3 -m json.tool 2>/dev/null | head -15
fi

# ───────────────────────────────────────────────────────────────
# HLS playlist test
# ───────────────────────────────────────────────────────────────
hdr "HLS playlist fetch"

# HLS pakai onDemand — fetch dulu untuk trigger pull
for i in 1 2 3 4 5; do
    HLS_HTTP=$(curl -sS -o /tmp/cammatrix_test_m3u8 -w "%{http_code}" --max-time 5 "$HLS_BASE/$SLUG/index.m3u8" || echo "000")
    if [ "$HLS_HTTP" = "200" ]; then
        ok "HLS playlist HTTP 200 (attempt $i)"
        echo "── m3u8 content ──"
        cat /tmp/cammatrix_test_m3u8
        echo "──"
        break
    fi
    warn "HLS attempt $i: HTTP $HLS_HTTP — wait 2s"
    sleep 2
done

if [ "$HLS_HTTP" != "200" ]; then
    err "HLS gagal setelah 5 attempt — kamera tidak bisa di-stream"
    err "Cek: journalctl -u mediamtx -n 30 --no-pager"
    err "Cek: curl http://127.0.0.1:9997/v3/paths/get/$SLUG | python3 -m json.tool"
fi

# ───────────────────────────────────────────────────────────────
# Stats
# ───────────────────────────────────────────────────────────────
hdr "Bytes received (after 4s)"

sleep 4
PATH_INFO=$(curl -sS "http://127.0.0.1:9997/v3/paths/get/$SLUG" 2>/dev/null || echo '{}')
echo "$PATH_INFO" | python3 -m json.tool 2>/dev/null | grep -E "ready|bytes|tracks" | head -10

# ───────────────────────────────────────────────────────────────
# Cleanup (DELETE kamera test)
# ───────────────────────────────────────────────────────────────
if [ "$KEEP" = "1" ]; then
    hdr "KEEP=1 — kamera test tidak di-delete (id=$CAM_ID)"
else
    hdr "DELETE camera test"
    DEL=$(curl -sS -L -w "%{http_code}" -X DELETE "$API_BASE/cameras/$CAM_ID" \
        -H "Authorization: Bearer $TOKEN")
    if echo "$DEL" | grep -q "200"; then
        ok "Camera test (id=$CAM_ID) deleted"
    else
        warn "Cleanup gagal — hapus manual via API: DELETE /cameras/$CAM_ID"
    fi
fi

rm -f /tmp/cammatrix_test_m3u8

if [ "$HLS_HTTP" = "200" ]; then
    echo
    echo -e "${GREEN}═══════════════════════════════════════════${NC}"
    echo -e "${GREEN}  TEST PASSED: kamera bisa di-add + stream${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════${NC}"
    exit 0
else
    echo
    echo -e "${RED}═══════════════════════════════════════════${NC}"
    echo -e "${RED}  TEST FAILED: HLS tidak respond${NC}"
    echo -e "${RED}═══════════════════════════════════════════${NC}"
    exit 1
fi
