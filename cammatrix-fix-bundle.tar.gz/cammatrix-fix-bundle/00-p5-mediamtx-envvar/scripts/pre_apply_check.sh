#!/bin/bash
# Pre-apply diagnostic — jalankan SEBELUM apply.sh untuk capture state awal.
# Outputnya bisa di-save sebagai bukti before/after.
set -uo pipefail

APP_DIR="${APP_DIR:-/var/www/CamMatrix}"
TARGET_FILE="${APP_DIR}/backend/app/api/v1/endpoints/cameras.py"

echo "═══════════════════════════════════════════════════════"
echo "  CamMatrix Pre-Apply Diagnostic"
echo "  Date: $(date)"
echo "  Host: $(hostname) ($(hostname -I | awk '{print $1}'))"
echo "═══════════════════════════════════════════════════════"

echo
echo "── Service state ──"
for s in cammatrix-backend cammatrix-frontend mediamtx postgresql minio; do
    state=$(systemctl is-active $s 2>/dev/null)
    printf "  %-22s %s\n" "$s" "${state:-unknown}"
done

echo
echo "── MediaMTX restart counter (lifetime) ──"
sudo systemctl show mediamtx -p NRestarts -p ActiveEnterTimestamp -p Result 2>/dev/null

echo
echo "── MediaMTX last error ──"
sudo journalctl -u mediamtx -n 20 --no-pager 2>/dev/null | grep -iE "ERR|error|fail" | tail -5

echo
echo "── Patch file existence ──"
if [ -f "$TARGET_FILE" ]; then
    echo "  $TARGET_FILE exists"
    echo "  size: $(stat -c %s $TARGET_FILE) bytes"
    echo "  mtime: $(stat -c %y $TARGET_FILE)"
    echo "  has env-var pattern (vulnerable): $(grep -c '\${CAM_' $TARGET_FILE)"
else
    echo "  $TARGET_FILE NOT FOUND"
fi

echo
echo "── mediamtx.yml current state ──"
sudo head -30 /etc/mediamtx/mediamtx.yml 2>/dev/null

echo
echo "── Cameras in DB ──"
sudo -u postgres psql cctv_vms -c "SELECT id, name, owner_id, LEFT(rtsp_url, 60) AS rtsp_preview FROM cameras ORDER BY id;" 2>/dev/null

echo
echo "═══════════════════════════════════════════════════════"
echo "  Save this output:  ./pre_apply_check.sh > before.log"
echo "═══════════════════════════════════════════════════════"
