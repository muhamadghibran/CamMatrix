#!/bin/bash
# CamMatrix P5 Fix — Apply script
# Usage: sudo ./apply.sh
#
# Bug yang di-fix: MediaMTX v1.x tidak substitute env var di paths.*.source.
# Backend lama tulis `source: ${CAM_x_y_RTSP_URL}` → MediaMTX crash loop.
# Fix: tulis URL plain langsung ke mediamtx.yml (mode 600).
set -euo pipefail

# ───────────────────────────────────────────────────────────────
# Konfigurasi (override via env var bila path beda)
# ───────────────────────────────────────────────────────────────
APP_DIR="${APP_DIR:-/var/www/CamMatrix}"
BACKEND_DIR="${BACKEND_DIR:-${APP_DIR}/backend}"
TARGET_FILE="${BACKEND_DIR}/app/api/v1/endpoints/cameras.py"
MEDIAMTX_CONFIG="${MEDIAMTX_CONFIG:-/etc/mediamtx/mediamtx.yml}"
MEDIAMTX_ENV="${MEDIAMTX_ENV:-/etc/mediamtx/cameras.env}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/cammatrix-fix-p5}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'
err()  { echo -e "${RED}✗ $*${NC}" >&2; }
ok()   { echo -e "${GREEN}✓ $*${NC}"; }
warn() { echo -e "${YELLOW}! $*${NC}"; }
hdr()  { echo; echo "=== $* ==="; }

# ───────────────────────────────────────────────────────────────
# Pre-flight
# ───────────────────────────────────────────────────────────────
hdr "Pre-flight check"

if [ "$EUID" -ne 0 ]; then
    err "Harus dijalankan dengan sudo/root."
    exit 1
fi

if [ ! -f "$TARGET_FILE" ]; then
    err "File target tidak ditemukan: $TARGET_FILE"
    err "Override path dengan: APP_DIR=/path/ke/app ./apply.sh"
    exit 1
fi

if [ ! -f "$SCRIPT_DIR/backend/app/api/v1/endpoints/cameras.py" ]; then
    err "Source patch tidak ditemukan di $SCRIPT_DIR/backend/..."
    err "Pastikan kamu jalankan dari direktori hasil extract tar.gz."
    exit 1
fi

if ! command -v systemctl >/dev/null 2>&1; then
    err "systemctl tidak ada — script ini hanya untuk systemd-based system."
    exit 1
fi

ok "Path target: $TARGET_FILE"
ok "Source patch: $SCRIPT_DIR/backend/app/api/v1/endpoints/cameras.py"

# ───────────────────────────────────────────────────────────────
# Backup
# ───────────────────────────────────────────────────────────────
hdr "Backup"

mkdir -p "$BACKUP_DIR"
TS=$(date +%Y%m%d-%H%M%S)
cp -p "$TARGET_FILE" "$BACKUP_DIR/cameras.py.bak-$TS"
ok "Backup cameras.py → $BACKUP_DIR/cameras.py.bak-$TS"

if [ -f "$MEDIAMTX_CONFIG" ]; then
    cp -p "$MEDIAMTX_CONFIG" "$BACKUP_DIR/mediamtx.yml.bak-$TS"
    ok "Backup mediamtx.yml → $BACKUP_DIR/mediamtx.yml.bak-$TS"
fi

if [ -f "$MEDIAMTX_ENV" ]; then
    cp -p "$MEDIAMTX_ENV" "$BACKUP_DIR/cameras.env.bak-$TS"
    ok "Backup cameras.env → $BACKUP_DIR/cameras.env.bak-$TS"
fi

# ───────────────────────────────────────────────────────────────
# Stop MediaMTX (kalau lagi crash loop, hentikan dulu)
# ───────────────────────────────────────────────────────────────
hdr "Stop MediaMTX"

if systemctl is-active mediamtx >/dev/null 2>&1; then
    systemctl stop mediamtx
    ok "MediaMTX di-stop"
else
    warn "MediaMTX sudah inactive"
fi

# Hentikan auto-restart loop kalau lagi crash terus-menerus
if systemctl show mediamtx -p ActiveState | grep -q "activating"; then
    systemctl stop mediamtx
    sleep 1
    ok "Auto-restart loop dihentikan"
fi

# ───────────────────────────────────────────────────────────────
# Apply patched cameras.py
# ───────────────────────────────────────────────────────────────
hdr "Apply patch"

# Ambil owner asli supaya permission tidak berubah
ORIG_OWNER=$(stat -c "%U:%G" "$TARGET_FILE")
ORIG_MODE=$(stat -c "%a" "$TARGET_FILE")

cp "$SCRIPT_DIR/backend/app/api/v1/endpoints/cameras.py" "$TARGET_FILE"
chown "$ORIG_OWNER" "$TARGET_FILE"
chmod "$ORIG_MODE" "$TARGET_FILE"
ok "cameras.py replaced (owner $ORIG_OWNER, mode $ORIG_MODE)"

# Sanity check syntax Python
if [ -x "$BACKEND_DIR/venv/bin/python" ]; then
    if "$BACKEND_DIR/venv/bin/python" -c "import ast; ast.parse(open('$TARGET_FILE').read())"; then
        ok "Python syntax check passed"
    else
        err "Python syntax error di patched file — rolling back."
        cp "$BACKUP_DIR/cameras.py.bak-$TS" "$TARGET_FILE"
        chown "$ORIG_OWNER" "$TARGET_FILE"
        chmod "$ORIG_MODE" "$TARGET_FILE"
        exit 1
    fi
fi

# ───────────────────────────────────────────────────────────────
# Restart backend supaya load module baru
# ───────────────────────────────────────────────────────────────
hdr "Restart backend"

if systemctl list-unit-files | grep -q "cammatrix-backend"; then
    systemctl restart cammatrix-backend
    sleep 2
    if systemctl is-active cammatrix-backend >/dev/null 2>&1; then
        ok "cammatrix-backend restarted"
    else
        err "cammatrix-backend gagal start. Cek: journalctl -u cammatrix-backend -n 50"
        err "Rollback: cp $BACKUP_DIR/cameras.py.bak-$TS $TARGET_FILE && systemctl restart cammatrix-backend"
        exit 1
    fi
else
    warn "Service cammatrix-backend tidak ditemukan — restart manual"
fi

# ───────────────────────────────────────────────────────────────
# Re-sync mediamtx.yml dari DB (lewat backend langsung)
# ───────────────────────────────────────────────────────────────
hdr "Re-sync mediamtx.yml dari database"

# Tentukan user backend service
BACKEND_USER=$(systemctl show cammatrix-backend -p User --value 2>/dev/null || echo "root")
[ -z "$BACKEND_USER" ] && BACKEND_USER="root"

cat > /tmp/cammatrix_resync_paths.py <<'PYEOF'
import asyncio
import sys

sys.path.insert(0, "/var/www/CamMatrix/backend")

from sqlalchemy import select
from app.db.session import async_session
from app.models.camera import Camera
from app.api.v1.endpoints.cameras import write_cameras_paths


async def resync():
    async with async_session() as db:
        result = await db.execute(select(Camera))
        cams = result.scalars().all()
        write_cameras_paths(cams)
        return len(cams)


count = asyncio.run(resync())
print(f"Re-synced {count} kamera ke mediamtx.yml")
PYEOF

cd "$BACKEND_DIR"
if [ "$BACKEND_USER" = "root" ]; then
    "$BACKEND_DIR/venv/bin/python" /tmp/cammatrix_resync_paths.py || warn "Re-sync gagal — coba manual via API"
else
    sudo -u "$BACKEND_USER" "$BACKEND_DIR/venv/bin/python" /tmp/cammatrix_resync_paths.py || warn "Re-sync gagal — coba manual via API"
fi
rm -f /tmp/cammatrix_resync_paths.py

# ───────────────────────────────────────────────────────────────
# Start MediaMTX
# ───────────────────────────────────────────────────────────────
hdr "Start MediaMTX"

systemctl reset-failed mediamtx 2>/dev/null || true
systemctl start mediamtx
sleep 3

if systemctl is-active mediamtx >/dev/null 2>&1; then
    ok "MediaMTX active"
    NRESTART=$(systemctl show mediamtx -p NRestarts --value 2>/dev/null || echo "?")
    echo "  NRestarts (lifetime): $NRESTART"
else
    err "MediaMTX gagal start setelah patch."
    err "Log: journalctl -u mediamtx -n 50 --no-pager"
    exit 1
fi

# ───────────────────────────────────────────────────────────────
# Smoke test
# ───────────────────────────────────────────────────────────────
hdr "Smoke test"

# Test 1: MediaMTX API up
if curl -fsS --max-time 3 http://127.0.0.1:9997/v3/paths/list >/dev/null; then
    ok "MediaMTX API :9997 reachable"
else
    err "MediaMTX API :9997 tidak respond"
    exit 1
fi

# Test 2: HLS port listening
if ss -tln | grep -q ":8888 "; then
    ok "HLS port :8888 listening"
else
    warn "HLS port :8888 tidak listen"
fi

# Test 3: Backend API reachable
if curl -fsS --max-time 3 -o /dev/null -w "%{http_code}" http://127.0.0.1:8000/openapi.json | grep -qE "^(200|404)$"; then
    ok "Backend API responding"
else
    warn "Backend API tidak respond — cek service"
fi

# Test 4: mediamtx.yml mode
ACTUAL_MODE=$(stat -c "%a" "$MEDIAMTX_CONFIG")
if [ "$ACTUAL_MODE" = "600" ]; then
    ok "mediamtx.yml mode 600 (credential terlindungi)"
else
    warn "mediamtx.yml mode = $ACTUAL_MODE (expected 600). Set: chmod 600 $MEDIAMTX_CONFIG"
fi

# ───────────────────────────────────────────────────────────────
# Selesai
# ───────────────────────────────────────────────────────────────
hdr "Selesai"

cat <<EOF

${GREEN}Patch P5 berhasil diterapkan.${NC}

Verifikasi tambahan (opsional):
  - Login dari browser, lihat kamera existing → status harus jadi "live" dalam 5-10 detik
  - Cek HLS: curl -fsS http://127.0.0.1:8888/cam_X_Y/index.m3u8
  - Test add kamera baru: jalankan ./scripts/test_add_camera_pjn.sh

Backup tersimpan di:
  $BACKUP_DIR/

Rollback (kalau perlu):
  sudo cp $BACKUP_DIR/cameras.py.bak-$TS $TARGET_FILE
  sudo systemctl restart cammatrix-backend
  sudo systemctl restart mediamtx

EOF
