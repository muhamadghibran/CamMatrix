# CHANGELOG

## v1.0 — 2026-04-27

### Fixed
- **P5 (CRITICAL)**: `write_cameras_paths()` sekarang tulis URL plain ke `mediamtx.yml`, bukan env var reference. Mengakhiri MediaMTX crash loop indefinite di prod (counter 489+ di server `cam00@103.180.198.240` saat ditemukan).

### Changed
- `mediamtx.yml` ditulis dengan **mode 600** (sebelumnya default umask, biasanya 644). Konsekuensi credential plaintext: file tidak readable user lain.
- Write strategy jadi **atomic** (tmp file + `os.replace`).
- **Auto-backup** ke `/var/backups/cctv/mediamtx-<ts>.yml` sebelum tiap rewrite.
- **Smart reload**: cek service state dulu (`systemctl is-active mediamtx`), kalau active → reload, kalau inactive → start. Sebelumnya reload always, gagal silent kalau service stopped.
- `update_camera` (PUT endpoint) sekarang ikut trigger `write_cameras_to_config`. Sebelumnya update DB tapi YAML tidak ter-sync → MediaMTX pull URL lama.

### Deprecated
- `cameras.env` masih di-write (komentar saja, isi kosong) untuk backward-compat dengan systemd `EnvironmentFile=-/etc/mediamtx/cameras.env`. Boleh di-remove dari unit di iterasi berikutnya.

### Known issues / not fixed di patch ini
- **N5 partial regression**: credential RTSP plaintext di YAML kembali. Mitigated by mode 600 + apiAddress 127.0.0.1, tapi bukan defense-in-depth penuh. Rencana: aktifkan `authInternalUsers` di MediaMTX untuk lock down `:9997 paths/list`.
- **P1 publisher IP whitelist**: `7e1e3a9` regression masih outstanding. Tidak di-touch oleh patch ini.
- **P4 scope JWT enforcement**: must_change_password tidak di-enforce. Tidak di-touch oleh patch ini.
- Audit findings lain (C3 lingering, H1, H2, H9, H12, M20) tidak di-touch.

Lihat `/mnt/mattixcambugfix.md` untuk daftar lengkap + cara fix tiap finding.
