# CamMatrix P5 Fix — Patch Package

> **Untuk**: tim magang CamMatrix
> **Versi**: 1.0 (2026-04-27)
> **Bug yang di-fix**: P5 — MediaMTX v1.x tidak substitute env var di field `paths.*.source`. Backend lama tulis `source: ${CAM_x_y_RTSP_URL}` → MediaMTX exit dengan `ERR: invalid source` → systemd auto-restart loop indefinite → semua kamera offline.

## TL;DR — Cara apply

```bash
# 1. Extract di server (sebagai user biasa, atau pindah ke /tmp)
tar -xzf cammatrix-fix-p5.tar.gz
cd cammatrix-fix-p5

# 2. Capture state SEBELUM apply (opsional tapi disarankan)
sudo ./scripts/pre_apply_check.sh > before.log 2>&1

# 3. Apply patch
sudo ./apply.sh

# 4. Verifikasi
sudo ./scripts/post_apply_test.sh

# 5. Test add kamera + verify HLS stream
./scripts/test_add_camera_pjn.sh
# (akan minta admin email + password, lalu DELETE kamera test setelah selesai)
```

## Apa isi paket ini

```
cammatrix-fix-p5/
├── README.md                                       # file ini
├── apply.sh                                        # apply script (utama)
├── backend/
│   └── app/api/v1/endpoints/
│       └── cameras.py                              # patched file (replacement penuh)
└── scripts/
    ├── pre_apply_check.sh                          # diagnostic before
    ├── post_apply_test.sh                          # smoke test after
    └── test_add_camera_pjn.sh                      # E2E test add+stream kamera
```

## Apa yang berubah di `cameras.py`

Function `write_cameras_paths` di-rewrite. Diff utama:

```diff
  # Lama (broken, env var tidak resolve di MediaMTX):
- env_lines.append(f"{env_key}={full_url}\n")
- paths_lines.append(
-     f"\n  {path_name}:\n"
-     f"    source: ${{{env_key}}}\n"
-     f"    sourceOnDemandCloseAfter: 60s\n"
- )

  # Baru (URL plain langsung ke YAML):
+ paths_lines.append(
+     f"\n  {path_name}:\n"
+     f"    source: {full_url}\n"
+     f"    sourceOnDemandCloseAfter: 60s\n"
+ )
```

Perubahan tambahan:
1. **Atomic write**: tulis ke `mediamtx.yml.tmp` lalu `os.replace()` — kalau crash di tengah, file lama utuh
2. **Auto-backup**: setiap rewrite, copy lama ke `/var/backups/cctv/mediamtx-<timestamp>.yml`
3. **mode 600** di `mediamtx.yml` (bukan default 644) — credential plaintext di YAML, file harus tidak readable user lain
4. **Smart reload**: cek `systemctl is-active mediamtx` dulu — kalau active, `reload`; kalau inactive, `start`. Reload pada service stopped sebelumnya error silent
5. **`update_camera`** sekarang ikut trigger `write_cameras_to_config` — sebelumnya update tidak rewrite YAML, sehingga PUT yang ubah RTSP URL tidak ter-apply ke MediaMTX
6. **`cameras.env`** masih di-tulis (untuk backward-compat dengan systemd `EnvironmentFile`) tapi isinya kosong/komentar — file ini tidak lagi dipakai

## Trade-off yang harus magang sadari

✅ **Pro**:
- MediaMTX langsung jalan
- Hot-reload setiap CRUD kamera
- File mode 600 (defense-in-depth, walaupun bukan defense-in-secret)
- Atomic write + auto-backup

⚠️ **Trade-off**:
- Credential RTSP plaintext di `/etc/mediamtx/mediamtx.yml` (mitigasi: mode 600 + backup encrypted, jangan commit ke git, jangan kirim via Slack/email)
- Audit finding **N5 lama** (credential bocor di MediaMTX `:9997 paths/list`) **kembali muncul** kecuali MediaMTX API auth diaktifkan. Status: `apiAddress: 127.0.0.1:9997` di YAML melindungi dari akses publik, tapi process di server bisa baca. Roadmap: aktifkan `authInternalUsers` di YAML supaya `:9997` butuh auth basic
- `cameras.env` jadi vestigial — boleh dihapus dari systemd unit `EnvironmentFile=` di iterasi berikutnya

## Kalau ada yang gagal

### apply.sh fail di sanity check syntax
- File patched corrupt → restore backup, ulangi extract tar.gz

### MediaMTX masih crash setelah apply
```bash
# Cek log
sudo journalctl -u mediamtx -n 50 --no-pager

# Kalau masih ada `${CAM_` di error, mediamtx.yml belum ter-rewrite:
sudo cat /etc/mediamtx/mediamtx.yml | grep '\${'
# Kalau ada hits, jalankan manual re-sync:
cd /var/www/CamMatrix/backend
sudo -u root ./venv/bin/python -c "
import asyncio
from sqlalchemy import select
from app.db.session import async_session
from app.models.camera import Camera
from app.api.v1.endpoints.cameras import write_cameras_paths
async def r():
    async with async_session() as db:
        cams = (await db.execute(select(Camera))).scalars().all()
        write_cameras_paths(cams)
asyncio.run(r())
"
```

### Kamera ter-add tapi status tetap offline
- RTSP URL tidak reachable dari server (firewall, kamera mati, IP salah)
- Test manual: `ffprobe rtsp://...` di server. Kalau tidak bisa, masalah di network kamera bukan di sistem
- Backend log: `journalctl -u cammatrix-backend -n 50 --no-pager | grep -i error`

### Test `test_add_camera_pjn.sh` HLS gagal
- Pastikan kamera `192.168.28.6` reachable dari server (`ping 192.168.28.6`)
- Pastikan kredensial RTSP benar (kamera return 401 kalau salah → MediaMTX log akan menunjukkan)
- HLS pakai `sourceOnDemand` — playlist baru muncul setelah ada client request. Script sudah fetch beberapa kali untuk trigger pull

## Rollback

```bash
# Cari backup terbaru
ls -lt /var/backups/cammatrix-fix-p5/cameras.py.bak-* | head -1

# Restore
sudo cp /var/backups/cammatrix-fix-p5/cameras.py.bak-<TIMESTAMP> \
        /var/www/CamMatrix/backend/app/api/v1/endpoints/cameras.py
sudo systemctl restart cammatrix-backend

# (mediamtx akan crash loop balik karena cameras.py lama emit env var)
sudo systemctl stop mediamtx
```

Kalau setelah rollback ingin tetap ada state functional, edit `mediamtx.yml` manual hapus semua block `cam_*:` dan biarkan cuma `paths:\n  all_others:`.

## Untuk dipelajari lebih lanjut

Brief lengkap + hardening lain (P1 publisher mobile, P3 SERVER_IP order, P4 scope JWT, dst):
👉 `/mnt/mattixcambugfix.md` (di server mentor)

Audit putaran 3 raw findings:
👉 `/mnt/magangcam-reaudit-249dc19.md`

## FAQ

**Q: Kenapa pendekatan B (URL plain) bukan pendekatan A (MediaMTX HTTP API)?**
A: Pendekatan A lebih bersih (single source of truth = MediaMTX runtime), tapi butuh refactor besar + harus handle persistence (re-register saat MediaMTX restart). Patch ini target fix cepat. Roadmap: migrate ke pendekatan A setelah hardening lain (P1, P4) tuntas.

**Q: Kenapa `update_camera` sekarang juga panggil `write_cameras_to_config`?**
A: Bug lama: PUT ubah `rtsp_url` di DB tapi mediamtx.yml tidak ter-update → MediaMTX masih pull URL lama. Fix sekalian.

**Q: `cameras.env` masih di-write tapi kosong, kenapa tidak dihapus?**
A: systemd unit punya `EnvironmentFile=-/etc/mediamtx/cameras.env`. Tanda `-` artinya optional, jadi sebenarnya bisa dihapus. Patch ini conservative — jangan ubah unit file. Iterasi berikutnya: hapus baris `EnvironmentFile=` dari `mediamtx.service` + hapus file ini.

**Q: Ada test untuk pendekatan A (HTTP API)?**
A: Belum di paket ini. Lihat `/mnt/mattixcambugfix.md` Fix 0 untuk rancangan.
