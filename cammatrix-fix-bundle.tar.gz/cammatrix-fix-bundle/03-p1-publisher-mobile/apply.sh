#!/bin/bash
# Module 03: P1 — pisah role publisher backend (localhost only) vs mobile_publisher (Larix)
#
# Bug: commit 7e1e3a9 hapus `ips: [127.0.0.1/32]` dari role publisher (yang punya
# permission `api`) agar Larix mobile bisa push. Hasilnya: siapa pun yang dapat
# password publisher (env file, log, backup) bisa akses admin API + override kamera.
#
# Fix: kembalikan ips lock, buat user `mobile_publisher` baru tanpa permission `api`.
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/CamMatrix}"
MEDIAMTX_CONFIG="${MEDIAMTX_CONFIG:-/etc/mediamtx/mediamtx.yml}"
MEDIAMTX_ENV_FILE="${MEDIAMTX_ENV_FILE:-/etc/mediamtx/mediamtx.env}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/cammatrix-fix-p5}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok() { echo -e "${GREEN}✓ $*${NC}"; }
err() { echo -e "${RED}✗ $*${NC}" >&2; }
warn() { echo -e "${YELLOW}! $*${NC}"; }

[ "$EUID" -eq 0 ] || { err "Harus sudo"; exit 1; }

mkdir -p "$BACKUP_DIR"
TS=$(date +%Y%m%d-%H%M%S)

# ── 1. Backup state ───────────────────────────────────────────────────
[ -f "$MEDIAMTX_CONFIG" ] && cp -p "$MEDIAMTX_CONFIG" "$BACKUP_DIR/mediamtx.yml.bak-$TS"
[ -f "$MEDIAMTX_ENV_FILE" ] && cp -p "$MEDIAMTX_ENV_FILE" "$BACKUP_DIR/mediamtx.env.bak-$TS"
ok "Backup state di $BACKUP_DIR"

# ── 2. Generate password mobile_publisher (kalau belum ada) ────────────
if grep -q "MTX_MOBILE_PUBLISHER_PASS=" "$MEDIAMTX_ENV_FILE" 2>/dev/null; then
    MTX_MOBILE_PUBLISHER_PASS=$(grep "^MTX_MOBILE_PUBLISHER_PASS=" "$MEDIAMTX_ENV_FILE" | cut -d= -f2)
    ok "MTX_MOBILE_PUBLISHER_PASS sudah ada di $MEDIAMTX_ENV_FILE"
else
    MTX_MOBILE_PUBLISHER_PASS=$(openssl rand -hex 16)
    echo "MTX_MOBILE_PUBLISHER_PASS=${MTX_MOBILE_PUBLISHER_PASS}" >> "$MEDIAMTX_ENV_FILE"
    chmod 600 "$MEDIAMTX_ENV_FILE"
    ok "Generated MTX_MOBILE_PUBLISHER_PASS, ditambahkan ke $MEDIAMTX_ENV_FILE"
fi

# ── 3. Tulis base mediamtx.yml dari template ──────────────────────────
# CATATAN: kalau backend rewrite YAML (Module 00 P5 fix), block paths akan
# di-append di bawah marker `all_others:`. Base block (auth dst) PRESERVED
# karena write_cameras_paths baca sampai marker.
cp "$SCRIPT_DIR/mediamtx.yml.template" "$MEDIAMTX_CONFIG"
chmod 600 "$MEDIAMTX_CONFIG"
chown root:root "$MEDIAMTX_CONFIG"
ok "Base mediamtx.yml ditulis dengan auth 3-role (publisher localhost / mobile_publisher / viewer)"

# ── 4. Restart MediaMTX ──────────────────────────────────────────────
echo
echo "=== Restart MediaMTX ==="
systemctl reset-failed mediamtx 2>/dev/null || true
systemctl restart mediamtx
sleep 3

if systemctl is-active mediamtx >/dev/null 2>&1; then
    ok "MediaMTX active"
else
    err "MediaMTX gagal start. Restore backup + check log."
    err "  cp $BACKUP_DIR/mediamtx.yml.bak-$TS $MEDIAMTX_CONFIG"
    err "  journalctl -u mediamtx -n 30 --no-pager"
    exit 1
fi

# ── 5. Re-sync paths dari DB (kalau Module 00 P5 sudah di-apply) ──────
BACKEND_DIR="$APP_DIR/backend"
if [ -f "$BACKEND_DIR/app/api/v1/endpoints/cameras.py" ]; then
    echo
    echo "=== Re-sync paths dari DB ==="
    cat > /tmp/cammatrix_resync_p1.py <<'PYEOF'
import asyncio, sys
sys.path.insert(0, "/var/www/CamMatrix/backend")
from sqlalchemy import select
from app.db.session import async_session
from app.models.camera import Camera
from app.api.v1.endpoints.cameras import write_cameras_paths

async def r():
    async with async_session() as db:
        cams = (await db.execute(select(Camera))).scalars().all()
        write_cameras_paths(cams)

asyncio.run(r())
print("Resynced.")
PYEOF
    BACKEND_USER=$(systemctl show cammatrix-backend -p User --value 2>/dev/null || echo "root")
    [ -z "$BACKEND_USER" ] && BACKEND_USER="root"
    if [ "$BACKEND_USER" = "root" ]; then
        "$BACKEND_DIR/venv/bin/python" /tmp/cammatrix_resync_p1.py || warn "Re-sync skip"
    else
        sudo -u "$BACKEND_USER" "$BACKEND_DIR/venv/bin/python" /tmp/cammatrix_resync_p1.py || warn "Re-sync skip"
    fi
    rm -f /tmp/cammatrix_resync_p1.py
fi

# ── 6. Print kredensial Larix mobile ─────────────────────────────────
echo
cat <<EOF

═══════════════════════════════════════════════════════
  KREDENSIAL LARIX MOBILE PUBLISHER (CATAT SEKARANG)
═══════════════════════════════════════════════════════

  Larix Broadcaster setting:
    Connection URL: rtsp://${HOSTNAME:-<server-ip>}:8554/mobile_<NAMA-KAMERA>
    Username:       mobile_publisher
    Password:       ${MTX_MOBILE_PUBLISHER_PASS}

  Path-name HARUS prefix dengan "mobile_" (mis. mobile_kantor, mobile_lobi).
  Path lain akan di-tolak oleh MediaMTX (permission: action=publish path=mobile_*).

  Backend FastAPI sekarang HANYA bisa push dari localhost (ips:127.0.0.1/32).
  Kalau backend di server berbeda dari MediaMTX, ubah ips ke IP backend.

═══════════════════════════════════════════════════════
EOF
