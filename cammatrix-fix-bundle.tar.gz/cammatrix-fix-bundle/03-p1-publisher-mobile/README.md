# Module 03 — P1 Publisher Mobile Separation

## Masalah

Commit `7e1e3a9` (2026-04-25) "fix: remove IP restriction for publisher to allow Larix mobile streaming" menghapus baris:
```yaml
ips: [127.0.0.1/32]
```
dari role `publisher` di `mediamtx.yml`. Tapi role `publisher` punya permission **`api`** (akses penuh MediaMTX admin API). Hasilnya: siapa pun yang dapat password `MTX_PUBLISHER_PASS` (env file backup, log, journalctl) bisa akses admin API + override stream kamera asli.

## Threat model

```
Attacker dari internet:
  1. Dapat password publisher (32-hex char) lewat backup leak / log dump
  2. RTSP PUBLISH ke rtsp://server:8554/cam_2_19 dengan stream palsu →
     CCTV asli ter-override dengan video attacker
  3. ATAU panggil :9997/v3/config/paths/list → enumerate semua kamera + RTSP source
  4. ATAU panggil :9997/v3/config/paths/delete → DoS sistem
```

Sebelum `7e1e3a9`: attack di atas mustahil karena MediaMTX drop koneksi non-localhost untuk role publisher.

## Fix — pisah user, pisah scope

3 user di `authInternalUsers`:

| User | Source IP | Permission | Path | Pemakai |
|---|---|---|---|---|
| `publisher` | **127.0.0.1/32** only | publish + api | * | Backend FastAPI (di server yang sama) |
| `mobile_publisher` | mana saja | publish saja | **`mobile_*`** | Larix Broadcaster di HP |
| `viewer` | mana saja | read + playback | * | Public viewer |

Kunci:
- `publisher` tetap punya `api` permission (perlu untuk register paths runtime), tapi **dikunci ke localhost**.
- `mobile_publisher` BARU, tidak punya `api`, dikunci ke path-prefix `mobile_*` saja. Larix tidak bisa override kamera utama (`cam_2_19`, dst).

## Cara apply

```bash
sudo ./apply.sh
```

Apply script:
1. Backup state lama
2. Generate `MTX_MOBILE_PUBLISHER_PASS` random (kalau belum ada)
3. Append ke `/etc/mediamtx/mediamtx.env`
4. Tulis ulang `/etc/mediamtx/mediamtx.yml` dengan template 3-role
5. Restart MediaMTX
6. Re-sync paths dari DB (kalau Module 00 P5 sudah di-apply)
7. Print kredensial Larix untuk dicatat

## Konfigurasi Larix Broadcaster di HP

```
Connection URL: rtsp://<server-ip>:8554/mobile_<NAMA-KAMERA>
                  contoh: rtsp://103.180.198.240:8554/mobile_lobi-utama
Username:       mobile_publisher
Password:       (lihat output apply.sh)
```

**Penting**: nama path harus prefix dengan `mobile_`. Path lain (mis. `cam_2_19`) akan ditolak MediaMTX karena permission `path: mobile_*`.

## Verifikasi

```bash
# 1. Cek base config tetap ada hardening setelah apply
sudo grep -A2 "user: publisher" /etc/mediamtx/mediamtx.yml | grep "127.0.0.1"
# Expected: ada baris "ips: [127.0.0.1/32]"

# 2. Cek mobile_publisher tidak punya api
sudo grep -A5 "user: mobile_publisher" /etc/mediamtx/mediamtx.yml | grep -c "api"
# Expected: 0

# 3. Test push dari Larix → cek MediaMTX log
sudo journalctl -u mediamtx -f
# Saat Larix connect, harus muncul: [path mobile_xxx] [RTSP publisher] connected
```

## Rollback

```bash
ls -lt /var/backups/cammatrix-fix-p5/mediamtx.yml.bak-* | head -1
sudo cp /var/backups/cammatrix-fix-p5/mediamtx.yml.bak-<TS> /etc/mediamtx/mediamtx.yml
sudo systemctl restart mediamtx
```

## Catatan integrasi dengan Module 00 (P5)

Module 00 fix `write_cameras_paths` baca base config sampai marker `all_others:`, lalu append dynamic paths. Block `authInternalUsers` di template Module 03 ada di ATAS marker → AMAN, tidak akan di-overwrite saat backend rewrite.

Kalau magang skip Module 00 (P5) tapi apply Module 03 ini, MediaMTX akan crash loop lagi (P5 belum fix). **Apply 00 dulu, baru 03**.
