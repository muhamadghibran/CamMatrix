#!/bin/bash
# Module 01: P4 JWT scope enforcement
#
# Bug: claim `scope=password_change_only` ada di JWT, tapi `deps.get_current_user`
# tidak pernah cek. Token "limited" tetap bisa hit semua endpoint = klaim cosmetic.
#
# Fix:
#   - Tambah dep baru `get_current_user_full_scope` yang reject token scope-limited
#   - Refactor: get_current_user TETAP terima scope-limited (untuk /auth/* saja)
#   - get_current_admin sekarang depend ke full_scope (bukan ke get_current_user)
#   - Sed-replace `Depends(deps.get_current_user)` di endpoints non-auth ke versi baru
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/CamMatrix}"
BACKEND_DIR="${BACKEND_DIR:-${APP_DIR}/backend}"
ENDPOINTS_DIR="${BACKEND_DIR}/app/api/v1/endpoints"
DEPS_FILE="${BACKEND_DIR}/app/api/deps.py"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/cammatrix-fix-p5}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok() { echo -e "${GREEN}✓ $*${NC}"; }
err() { echo -e "${RED}✗ $*${NC}" >&2; }
warn() { echo -e "${YELLOW}! $*${NC}"; }

[ "$EUID" -eq 0 ] || { err "Harus sudo/root"; exit 1; }
[ -f "$DEPS_FILE" ] || { err "$DEPS_FILE tidak ada"; exit 1; }

mkdir -p "$BACKUP_DIR"
TS=$(date +%Y%m%d-%H%M%S)
cp -p "$DEPS_FILE" "$BACKUP_DIR/deps.py.bak-$TS"
ok "Backup deps.py → $BACKUP_DIR/deps.py.bak-$TS"

# Apply replacement deps.py
ORIG_OWNER=$(stat -c "%U:%G" "$DEPS_FILE")
ORIG_MODE=$(stat -c "%a" "$DEPS_FILE")
cp "$SCRIPT_DIR/backend/app/api/deps.py" "$DEPS_FILE"
chown "$ORIG_OWNER" "$DEPS_FILE"
chmod "$ORIG_MODE" "$DEPS_FILE"

# Syntax check
if [ -x "$BACKEND_DIR/venv/bin/python" ]; then
    "$BACKEND_DIR/venv/bin/python" -c "import ast; ast.parse(open('$DEPS_FILE').read())" || {
        err "Syntax error — rolling back"
        cp "$BACKUP_DIR/deps.py.bak-$TS" "$DEPS_FILE"
        exit 1
    }
    ok "Syntax check passed"
fi

# Sed-replace: Depends(deps.get_current_user) → Depends(deps.get_current_user_full_scope)
# di SEMUA endpoint kecuali auth.py (yang sengaja accept scope-limited)
echo
echo "=== Refactor endpoint dependencies ==="

CHANGED_FILES=()
for file in "$ENDPOINTS_DIR"/*.py; do
    base=$(basename "$file")
    # Skip auth.py — endpoint /me, /change-password, /logout sengaja accept scope-limited
    if [ "$base" = "auth.py" ]; then
        echo "  skip $base (sengaja pakai get_current_user)"
        continue
    fi

    # Backup + sed-replace
    if grep -q "Depends(deps.get_current_user)" "$file"; then
        cp -p "$file" "$BACKUP_DIR/${base}.bak-$TS"
        sed -i 's/Depends(deps\.get_current_user)/Depends(deps.get_current_user_full_scope)/g' "$file"
        # Verifikasi syntax
        if [ -x "$BACKEND_DIR/venv/bin/python" ]; then
            if ! "$BACKEND_DIR/venv/bin/python" -c "import ast; ast.parse(open('$file').read())"; then
                err "Syntax error di $file — rolling back"
                cp "$BACKUP_DIR/${base}.bak-$TS" "$file"
                continue
            fi
        fi
        CHANGED_FILES+=("$base")
        ok "patched $base"
    fi
done

echo
echo "=== Restart backend ==="
systemctl restart cammatrix-backend
sleep 2
if systemctl is-active cammatrix-backend >/dev/null 2>&1; then
    ok "cammatrix-backend running"
else
    err "Backend gagal start. Check: journalctl -u cammatrix-backend -n 30"
    exit 1
fi

echo
echo "Files changed: ${CHANGED_FILES[*]}"
echo "Backup di: $BACKUP_DIR/*.bak-$TS"
echo
echo "Verifikasi: jalankan tests/test_jwt_scope.sh"
