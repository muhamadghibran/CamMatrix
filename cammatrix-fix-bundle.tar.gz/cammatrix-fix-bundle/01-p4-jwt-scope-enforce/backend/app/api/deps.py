from typing import AsyncGenerator, Annotated
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import decode_access_token
from app.models.user import User, UserRole

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

DbSession = Annotated[AsyncSession, Depends(get_db)]


async def _resolve_user(token: str, db: AsyncSession) -> tuple[User, dict]:
    """Validate JWT, fetch user dari DB. Return (user, jwt_payload).
    Helper internal — bukan dependency langsung."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception

    user_id: str = payload.get("sub")
    if user_id is None:
        raise credentials_exception

    stmt = select(User).where(User.id == int(user_id))
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    if user is None:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")

    return user, payload


async def get_current_user(
    token: Annotated[str, Depends(oauth2_scheme)],
    db: DbSession,
) -> User:
    """
    Lenient auth: terima SEMUA token valid, termasuk yang scope-limited
    (`password_change_only`). HANYA dipakai di endpoint yang sengaja accept
    scope-limited token: `/auth/me`, `/auth/change-password`, `/auth/logout`.

    UNTUK endpoint lain, pakai `get_current_user_full_scope` agar token
    must_change_password TIDAK boleh akses.
    """
    user, _payload = await _resolve_user(token, db)
    return user


async def get_current_user_full_scope(
    token: Annotated[str, Depends(oauth2_scheme)],
    db: DbSession,
) -> User:
    """
    P4 FIX: Strict auth — TOLAK token dengan claim `scope=password_change_only`.
    User harus reset password dulu via `PUT /auth/change-password` sebelum
    bisa hit endpoint apa pun.

    PAKAI dep ini untuk SEMUA endpoint kecuali endpoint reset password.
    """
    user, payload = await _resolve_user(token, db)
    if payload.get("scope") == "password_change_only":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "Password change required. "
                "Reset password Anda lewat PUT /api/v1/auth/change-password "
                "sebelum mengakses resource lain."
            ),
        )
    return user


async def get_current_admin(
    current_user: Annotated[User, Depends(get_current_user_full_scope)],
) -> User:
    """Admin = role ADMIN + token full-scope (bukan password_change_only)."""
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="The user doesn't have enough privileges",
        )
    return current_user
