# Module 01 — P4 JWT Scope Enforcement

## Masalah

`backend/app/api/v1/endpoints/auth.py:97` inject `extra_claims["scope"] = "password_change_only"` ke JWT kalau `must_change_password=True`. **Tapi `deps.get_current_user` tidak pernah cek scope.**

Akibat: user yang baru di-seed pakai install_all.sh login → dapat token scope-limited → langsung hit `/cameras`, `/users`, `/recordings`, `/dashboard`. Fitur "must change password" cosmetic.

## Threat model

```
1. install_all.sh seed admin dengan password random + must_change_password=True
2. Operator install leak password ke shell history / journalctl / log
3. Attacker login dengan password tsb → dapat token scope=password_change_only
4. Attacker SKIP /change-password → langsung hit /cameras → enumerate semua kamera
5. Token VALID, claim "scope_limited" hanya cosmetic karena backend tidak cek
```

## Fix

`deps.py` sekarang punya 2 dependency:
- **`get_current_user`** — terima SEMUA token valid (untuk endpoint `/auth/me`, `/auth/change-password`, `/auth/logout`)
- **`get_current_user_full_scope`** — TOLAK token dengan `scope=password_change_only` → 403

Apply script automatically sed-replace `Depends(deps.get_current_user)` → `Depends(deps.get_current_user_full_scope)` di semua endpoint kecuali `auth.py`.

## Cara apply

```bash
sudo ./apply.sh
```

## Verifikasi

```bash
../tests/test_jwt_scope.sh    # E2E test, butuh admin email+password
```

## Trade-off

- ⚠️ User yang lupa ganti password sekarang BENAR-BENAR tidak bisa hit endpoint apapun. Frontend HARUS handle 403 dengan `detail` mengandung "Password change required" → redirect ke form ganti password. Kalau frontend tidak handle, user terjebak di loop login → 403.
- Frontend audit finding **H12** (isAuthenticated persist tanpa re-verify) jadi lebih urgent — token expired akan selalu 401, frontend harus redirect ke /login.

## Rollback

```bash
ls -lt /var/backups/cammatrix-fix-p5/deps.py.bak-* | head -1
sudo cp /var/backups/cammatrix-fix-p5/deps.py.bak-<TS> /var/www/CamMatrix/backend/app/api/deps.py
# Restore endpoints juga (sed yang reverse):
for f in /var/www/CamMatrix/backend/app/api/v1/endpoints/*.py; do
    sudo sed -i 's/Depends(deps\.get_current_user_full_scope)/Depends(deps.get_current_user)/g' "$f"
done
sudo systemctl restart cammatrix-backend
```
