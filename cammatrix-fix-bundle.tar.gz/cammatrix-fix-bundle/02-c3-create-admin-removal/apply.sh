#!/bin/bash
# Module 02: C3 lingering — hapus create_admin.py + install CLI replacement
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/CamMatrix}"
BACKEND_DIR="${BACKEND_DIR:-${APP_DIR}/backend}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/cammatrix-fix-p5}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok() { echo -e "${GREEN}✓ $*${NC}"; }
err() { echo -e "${RED}✗ $*${NC}" >&2; }
warn() { echo -e "${YELLOW}! $*${NC}"; }

[ "$EUID" -eq 0 ] || { err "Harus sudo"; exit 1; }

mkdir -p "$BACKUP_DIR"
TS=$(date +%Y%m%d-%H%M%S)

# ── 1. Backup + hapus create_admin.py ─────────────────────────────────
if [ -f "$BACKEND_DIR/create_admin.py" ]; then
    cp -p "$BACKEND_DIR/create_admin.py" "$BACKUP_DIR/create_admin.py.bak-$TS"
    rm -f "$BACKEND_DIR/create_admin.py"
    ok "create_admin.py (admin123 hardcoded) dihapus → backup di $BACKUP_DIR"
else
    warn "create_admin.py tidak ada — sudah dihapus sebelumnya?"
fi

# Cek script lain yang mengandung 'admin123' (warning saja, tidak hapus)
echo
echo "=== Cek file lain yang mengandung 'admin123' ==="
LEFTOVERS=$(grep -rln "admin123" "$BACKEND_DIR" "$APP_DIR/linux_deployment" 2>/dev/null | grep -v venv | grep -v __pycache__ || true)
if [ -n "$LEFTOVERS" ]; then
    warn "Masih ada referensi 'admin123' di:"
    echo "$LEFTOVERS" | sed 's/^/    /'
    echo "    Review manual + ganti dengan generated random password."
fi

# ── 2. Install CLI replacement ────────────────────────────────────────
ORIG_OWNER=$(stat -c "%U:%G" "$BACKEND_DIR/main.py")
cp "$SCRIPT_DIR/backend/app/cli.py" "$BACKEND_DIR/app/cli.py"
chown "$ORIG_OWNER" "$BACKEND_DIR/app/cli.py"
chmod 644 "$BACKEND_DIR/app/cli.py"

# Syntax check
"$BACKEND_DIR/venv/bin/python" -c "import ast; ast.parse(open('$BACKEND_DIR/app/cli.py').read())" || {
    err "Syntax error di cli.py"
    exit 1
}
ok "app/cli.py installed"

# ── 3. List admins existing ──────────────────────────────────────────
echo
echo "=== Admin existing (untuk audit) ==="
BACKEND_USER=$(systemctl show cammatrix-backend -p User --value 2>/dev/null || echo "root")
[ -z "$BACKEND_USER" ] && BACKEND_USER="root"

cd "$BACKEND_DIR"
if [ "$BACKEND_USER" = "root" ]; then
    "$BACKEND_DIR/venv/bin/python" -m app.cli list-admins || warn "list-admins gagal"
else
    sudo -u "$BACKEND_USER" "$BACKEND_DIR/venv/bin/python" -m app.cli list-admins || warn "list-admins gagal"
fi

echo
echo "=== Selesai ==="
cat <<EOF

CLI replacement terpasang. Penggunaan:

  cd $BACKEND_DIR
  sudo -u $BACKEND_USER ./venv/bin/python -m app.cli seed-admin --email new@admin.com
  sudo -u $BACKEND_USER ./venv/bin/python -m app.cli reset-password --email old@admin.com
  sudo -u $BACKEND_USER ./venv/bin/python -m app.cli list-admins

Password DIBACA DARI STDIN (getpass) — TIDAK masuk shell history, TIDAK terlihat di ps aux.

Backup file lama:
  $BACKUP_DIR/create_admin.py.bak-$TS
EOF
