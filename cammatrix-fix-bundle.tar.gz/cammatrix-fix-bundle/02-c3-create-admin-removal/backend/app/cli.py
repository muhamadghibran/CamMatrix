"""
CamMatrix CLI — admin operations.

Replacement untuk `create_admin.py` yang punya hardcoded `admin123`.

Usage:
    cd /var/www/CamMatrix/backend
    sudo -u <backend_user> ./venv/bin/python -m app.cli seed-admin --email admin@example.com
    sudo -u <backend_user> ./venv/bin/python -m app.cli reset-password --email admin@example.com

Password dibaca dari stdin via getpass — tidak masuk shell history, tidak terlihat di `ps aux`.
"""
from __future__ import annotations

import asyncio
import getpass
import sys
from typing import Optional

import argparse

from sqlalchemy import select, text

from app.core.database import AsyncSessionLocal
from app.core.security import hash_password
from app.models.user import User, UserRole


MIN_PASSWORD_LEN = 12


def _read_password(prompt: str = "Password: ", confirm: bool = True) -> str:
    """Read password dari stdin (getpass) dengan konfirmasi."""
    pwd = getpass.getpass(prompt)
    if len(pwd) < MIN_PASSWORD_LEN:
        print(f"ERROR: password minimal {MIN_PASSWORD_LEN} karakter.", file=sys.stderr)
        sys.exit(1)
    if confirm:
        confirm_pwd = getpass.getpass("Confirm: ")
        if pwd != confirm_pwd:
            print("ERROR: password tidak cocok.", file=sys.stderr)
            sys.exit(1)
    return pwd


async def cmd_seed_admin(email: str, full_name: str, must_change: bool) -> int:
    pwd = _read_password()

    async with AsyncSessionLocal() as db:
        existing = (await db.execute(
            select(User).where(User.email == email)
        )).scalar_one_or_none()

        if existing:
            print(f"User dengan email {email} sudah ada (id={existing.id}, role={existing.role}).",
                  file=sys.stderr)
            print("Untuk reset password, gunakan: python -m app.cli reset-password --email " + email,
                  file=sys.stderr)
            return 1

        admin = User(
            full_name=full_name,
            email=email,
            hashed_password=hash_password(pwd),
            role=UserRole.ADMIN,
            is_active=True,
            must_change_password=must_change,
        )
        db.add(admin)
        await db.commit()
        print(f"OK: admin {email} created (must_change_password={must_change}).")
    return 0


async def cmd_reset_password(email: str) -> int:
    async with AsyncSessionLocal() as db:
        user = (await db.execute(
            select(User).where(User.email == email)
        )).scalar_one_or_none()

        if not user:
            print(f"ERROR: user {email} tidak ditemukan.", file=sys.stderr)
            return 1

        pwd = _read_password()
        user.hashed_password = hash_password(pwd)
        user.must_change_password = False
        db.add(user)
        await db.commit()
        print(f"OK: password {email} di-reset.")
    return 0


async def cmd_list_admins() -> int:
    async with AsyncSessionLocal() as db:
        admins = (await db.execute(
            select(User).where(User.role == UserRole.ADMIN).order_by(User.id)
        )).scalars().all()

        if not admins:
            print("(no admin users)")
            return 0
        print(f"{'ID':<4} {'Email':<35} {'Active':<7} {'MustChange':<10} {'Created':<20}")
        for u in admins:
            print(f"{u.id:<4} {u.email:<35} {str(u.is_active):<7} "
                  f"{str(getattr(u, 'must_change_password', False)):<10} "
                  f"{str(u.created_at)[:19] if u.created_at else '-':<20}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="cammatrix-cli", description="CamMatrix admin CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sa = sub.add_parser("seed-admin", help="Create admin user (password from stdin)")
    sa.add_argument("--email", required=True)
    sa.add_argument("--full-name", default="Administrator")
    sa.add_argument("--no-must-change", action="store_true",
                    help="Skip must_change_password flag (default: required)")

    rp = sub.add_parser("reset-password", help="Reset password user (from stdin)")
    rp.add_argument("--email", required=True)

    sub.add_parser("list-admins", help="List semua admin")

    args = parser.parse_args()

    if args.cmd == "seed-admin":
        return asyncio.run(cmd_seed_admin(
            args.email, args.full_name, must_change=not args.no_must_change,
        ))
    elif args.cmd == "reset-password":
        return asyncio.run(cmd_reset_password(args.email))
    elif args.cmd == "list-admins":
        return asyncio.run(cmd_list_admins())
    return 1


if __name__ == "__main__":
    sys.exit(main())
