# Module 02 — C3 lingering: hapus `create_admin.py` + CLI replacement

## Masalah

`backend/create_admin.py` punya:
```python
hashed_password=hash_password("admin123"),
is_active=True,
```
Tidak set `must_change_password=True`. Siapa pun yang `cd backend && python create_admin.py` dapat akun admin lemah, bypass total terhadap hardening install_all.sh yang sudah generate random password.

C3 startup safety check di `main.py:23-30` cuma block kalau password literal `admin123` masih dipakai — tapi dia tidak block penciptaan akun lemah dengan password lain (atau dengan password sama tapi via path lain).

## Fix

1. **Hapus `backend/create_admin.py`** (script lama)
2. **Install `backend/app/cli.py`** — CLI replacement dengan 3 sub-command:
   - `seed-admin` — create admin baru, password dibaca dari **stdin via getpass**
   - `reset-password` — reset password user existing
   - `list-admins` — lihat semua admin di DB

## Kenapa pakai getpass

- ❌ CLI argument: `python create_admin.py --password=secret` → masuk shell history (`~/.bash_history`), terlihat di `ps aux` saat berjalan
- ❌ Env var: `PASSWORD=secret python ...` → leak ke `/proc/<pid>/environ`, leak ke child process
- ✅ `getpass.getpass()` → dibaca dari TTY, tidak echo ke layar, tidak masuk history, tidak terlihat di `ps`

## Validasi password

- Minimal 12 karakter (configurable di `cli.py:MIN_PASSWORD_LEN`)
- Konfirmasi ulang (ketik 2x supaya tidak typo)
- Default `must_change_password=True` — operator harus reset di first login. Override dengan `--no-must-change`.

## Cara apply

```bash
sudo ./apply.sh
```

Apply script:
1. Backup `create_admin.py` ke `/var/backups/cammatrix-fix-p5/`
2. Hapus `create_admin.py`
3. Install `app/cli.py`
4. Print warning kalau masih ada referensi `admin123` di file lain (mis. README, install_all.sh)
5. List admin existing untuk audit

## Cara pakai CLI setelah install

```bash
cd /var/www/CamMatrix/backend

# Seed admin baru (password ditanya 2x dari stdin)
sudo -u root ./venv/bin/python -m app.cli seed-admin --email admin@vms.com

# Reset password user existing
sudo -u root ./venv/bin/python -m app.cli reset-password --email old@admin.com

# List semua admin
sudo -u root ./venv/bin/python -m app.cli list-admins
```

(Ganti `root` dengan user `cammatrix-backend.service` kalau systemd unit pakai user khusus — Modul 08 di roadmap mengubah ini.)

## Verifikasi

```bash
# Pastikan create_admin.py hilang
ls /var/www/CamMatrix/backend/create_admin.py
# Harus: No such file or directory

# Pastikan CLI bekerja
cd /var/www/CamMatrix/backend
./venv/bin/python -m app.cli list-admins
# Output: tabel admin existing
```

## Rollback

```bash
sudo cp /var/backups/cammatrix-fix-p5/create_admin.py.bak-<TS> \
        /var/www/CamMatrix/backend/create_admin.py
sudo rm /var/www/CamMatrix/backend/app/cli.py
```

(Jangan rollback kecuali ada masalah — `create_admin.py` adalah security debt yang harus hilang.)

## Tugas magang lanjutan (di luar scope module ini)

1. Update `linux_deployment/install_all.sh` — ganti panggilan `create_admin.py` dengan `python -m app.cli seed-admin --email admin@vms.com` (operator input password interaktif). Atau pertahankan auto-generate random password tapi tetap pakai CLI ini sebagai fallback.

2. Update `README.md` — hapus semua mention `admin@vms.com / admin123` (audit finding C3 round 1 belum di-fix).

3. Update tutorial / dokumentasi internal supaya semua referensi seed admin pakai `python -m app.cli`.
