#!/bin/bash
# Module 05: N3 — pisah ENCRYPTION_KEY dari SECRET_KEY
#
# Bug: Fernet key di-derive dari SECRET_KEY → leak SECRET_KEY = forge JWT
# admin DAN decrypt semua password kamera. Single point of failure.
#
# Fix: ENCRYPTION_KEY env var terpisah. Rotate semua ciphertext existing.
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/CamMatrix}"
BACKEND_DIR="${BACKEND_DIR:-${APP_DIR}/backend}"
ENV_FILE="${ENV_FILE:-${BACKEND_DIR}/.env}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/cammatrix-fix-p5}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok() { echo -e "${GREEN}✓ $*${NC}"; }
err() { echo -e "${RED}✗ $*${NC}" >&2; }
warn() { echo -e "${YELLOW}! $*${NC}"; }

[ "$EUID" -eq 0 ] || { err "Harus sudo"; exit 1; }

mkdir -p "$BACKUP_DIR"
TS=$(date +%Y%m%d-%H%M%S)
BACKEND_USER=$(systemctl show cammatrix-backend -p User --value 2>/dev/null || echo "root")
[ -z "$BACKEND_USER" ] && BACKEND_USER="root"

# ── 1. Backup semua file yang akan diubah ────────────────────────────
cp -p "$BACKEND_DIR/app/core/config.py" "$BACKUP_DIR/config.py.bak-$TS"
cp -p "$BACKEND_DIR/app/core/security.py" "$BACKUP_DIR/security.py.bak-$TS"
[ -f "$ENV_FILE" ] && cp -p "$ENV_FILE" "$BACKUP_DIR/.env.bak-$TS"
ok "Backup $BACKUP_DIR/{config,security}.py.bak-$TS, .env.bak-$TS"

# ── 2. Generate ENCRYPTION_KEY (kalau belum ada di .env) ─────────────
if [ -f "$ENV_FILE" ] && grep -q "^ENCRYPTION_KEY=" "$ENV_FILE"; then
    EXISTING=$(grep "^ENCRYPTION_KEY=" "$ENV_FILE" | cut -d= -f2)
    if [ -z "$EXISTING" ] || [ "${#EXISTING}" -lt 64 ]; then
        warn "ENCRYPTION_KEY ada tapi kosong/lemah — akan replace"
        sed -i '/^ENCRYPTION_KEY=/d' "$ENV_FILE"
        NEW_KEY=$("$BACKEND_DIR/venv/bin/python" -c "import secrets; print(secrets.token_hex(32))")
        echo "ENCRYPTION_KEY=$NEW_KEY" >> "$ENV_FILE"
        ok "Generated ENCRYPTION_KEY (64 hex char)"
    else
        ok "ENCRYPTION_KEY sudah ada di .env (skip generate)"
    fi
else
    NEW_KEY=$("$BACKEND_DIR/venv/bin/python" -c "import secrets; print(secrets.token_hex(32))")
    echo "ENCRYPTION_KEY=$NEW_KEY" >> "$ENV_FILE"
    ok "ENCRYPTION_KEY ditambahkan ke $ENV_FILE"
fi

# Pastikan SECRET_KEY != ENCRYPTION_KEY
SECRET_VAL=$(grep "^SECRET_KEY=" "$ENV_FILE" 2>/dev/null | cut -d= -f2 || echo "")
ENCKEY_VAL=$(grep "^ENCRYPTION_KEY=" "$ENV_FILE" 2>/dev/null | cut -d= -f2 || echo "")
if [ -n "$SECRET_VAL" ] && [ "$SECRET_VAL" = "$ENCKEY_VAL" ]; then
    err "SECRET_KEY == ENCRYPTION_KEY — defeats the purpose."
    err "Edit $ENV_FILE manual, ganti salah satunya dengan key baru."
    exit 1
fi

# ── 3. Run rotation script (re-encrypt password lama) ────────────────
echo
echo "=== Rotate ciphertext existing ==="
warn "PENTING: rotation HARUS dijalankan SEBELUM replace config.py + security.py"
warn "supaya data lama (encrypted dgn SECRET_KEY) bisa di-decrypt + re-encrypt."

cp "$SCRIPT_DIR/scripts/rotate_encryption_key.py" /tmp/rotate_encryption_key.py

# Source env, run rotation
set -a
source "$ENV_FILE"
set +a

cd "$BACKEND_DIR"
if [ "$BACKEND_USER" = "root" ]; then
    "$BACKEND_DIR/venv/bin/python" /tmp/rotate_encryption_key.py || {
        err "Rotation gagal — restore dari backup"
        exit 1
    }
else
    sudo -E -u "$BACKEND_USER" "$BACKEND_DIR/venv/bin/python" /tmp/rotate_encryption_key.py || {
        err "Rotation gagal — restore dari backup"
        exit 1
    }
fi
rm -f /tmp/rotate_encryption_key.py
ok "Rotation selesai"

# ── 4. Replace config.py + security.py ────────────────────────────────
ORIG_OWNER=$(stat -c "%U:%G" "$BACKEND_DIR/main.py")

cp "$SCRIPT_DIR/backend/app/core/config.py" "$BACKEND_DIR/app/core/config.py"
chown "$ORIG_OWNER" "$BACKEND_DIR/app/core/config.py"
"$BACKEND_DIR/venv/bin/python" -c "import ast; ast.parse(open('$BACKEND_DIR/app/core/config.py').read())" || exit 1
ok "config.py replaced (sekarang require ENCRYPTION_KEY)"

cp "$SCRIPT_DIR/backend/app/core/security.py" "$BACKEND_DIR/app/core/security.py"
chown "$ORIG_OWNER" "$BACKEND_DIR/app/core/security.py"
"$BACKEND_DIR/venv/bin/python" -c "import ast; ast.parse(open('$BACKEND_DIR/app/core/security.py').read())" || exit 1
ok "security.py replaced (Fernet derive dari ENCRYPTION_KEY)"

# ── 5. Restart backend ────────────────────────────────────────────────
echo
echo "=== Restart backend ==="
systemctl restart cammatrix-backend
sleep 2
if systemctl is-active cammatrix-backend >/dev/null 2>&1; then
    ok "cammatrix-backend running dengan ENCRYPTION_KEY terpisah"
else
    err "Backend gagal start. Check log:"
    err "  journalctl -u cammatrix-backend -n 30 --no-pager"
    err "Kalau error 'ENCRYPTION_KEY', cek $ENV_FILE."
    exit 1
fi

# ── 6. Update .env.example kalau ada ──────────────────────────────────
EXAMPLE_FILE="$BACKEND_DIR/.env.example"
if [ -f "$EXAMPLE_FILE" ] && ! grep -q "ENCRYPTION_KEY" "$EXAMPLE_FILE"; then
    cat >> "$EXAMPLE_FILE" <<'EOF'

# N3 FIX: Fernet encryption key untuk password kamera (terpisah dari SECRET_KEY).
# Generate: python -c "import secrets; print(secrets.token_hex(32))"
# JANGAN sama dengan SECRET_KEY.
ENCRYPTION_KEY=
EOF
    ok ".env.example diupdate dengan placeholder ENCRYPTION_KEY"
fi

echo
echo "=== Selesai ==="
cat <<EOF

Module 05 applied. Yang berubah:
  - ENCRYPTION_KEY env var baru (random 64 hex char)
  - $BACKEND_DIR/.env punya ENCRYPTION_KEY=...
  - Semua password kamera di DB di-rotate ke key baru
  - config.py + security.py refactored

Backup:
  $BACKUP_DIR/config.py.bak-$TS
  $BACKUP_DIR/security.py.bak-$TS
  $BACKUP_DIR/.env.bak-$TS

UNTUK DEPLOYMENT BARU:
  Update install_all.sh — generate ENCRYPTION_KEY juga, separate dari JWT_SECRET.
EOF
