# Module 05 — N3: Pisah `ENCRYPTION_KEY` dari `SECRET_KEY`

## Masalah

`backend/app/core/security.py:11-15`:
```python
def _get_fernet() -> Fernet:
    digest = hashlib.sha256(settings.SECRET_KEY.encode()).digest()
    key = base64.urlsafe_b64encode(digest)
    return Fernet(key)
```

Fernet key derive dari `SECRET_KEY` (yang juga sign JWT). **Single point of failure**:
- Leak SECRET_KEY → bisa **forge JWT admin** (impersonate siapa pun)
- Leak SECRET_KEY → bisa **decrypt semua password kamera** (lateral movement)

Dua dampak dari satu leak.

## Threat model

```
SECRET_KEY bocor (mis. via .env backup di tarball, log dump, env var di docker inspect):
  Attacker:
    1. Forge JWT admin: jwt.encode({"sub":"1","role":"ADMIN"}, SECRET_KEY)
    2. Login as admin tanpa password → akses semua endpoint
    3. SHA256(SECRET_KEY) → derive Fernet key → decrypt cameras.password
    4. Dapat plaintext kredensial RTSP semua kamera → akses ke kamera fisik
```

## Fix — key separation

Setelah patch:
- `SECRET_KEY` — tetap untuk JWT signing
- `ENCRYPTION_KEY` — env var baru, terpisah, untuk Fernet at-rest encryption

Compromise satu kunci = satu fungsi terdampak. Defense-in-depth.

## Cara apply

```bash
sudo ./apply.sh
```

Apply script (urutan PENTING):
1. Backup config.py + security.py + .env
2. Generate `ENCRYPTION_KEY` random (64 hex char), append ke `.env`
3. Validasi `SECRET_KEY != ENCRYPTION_KEY`
4. **Rotate semua ciphertext existing** (`scripts/rotate_encryption_key.py`):
   - Decrypt semua `cameras.password` dengan key lama (SECRET_KEY-derived)
   - Re-encrypt dengan key baru (ENCRYPTION_KEY-derived)
   - UPDATE row by row
   - Idempotent — kalau row sudah pakai key baru, skip
5. **Setelah rotation selesai**, replace `config.py` + `security.py` dengan versi baru
6. Restart backend
7. Update `.env.example` dengan placeholder

⚠️ **Urutan kritikal**: rotation HARUS jalan SEBELUM replace `security.py`. Kalau security.py diganti dulu, code baru tidak bisa decrypt data lama (karena baca `ENCRYPTION_KEY` yang belum punya ciphertext).

Apply.sh handle urutan dengan benar.

## Verifikasi

```bash
# 1. ENCRYPTION_KEY ada dan beda dari SECRET_KEY
sudo grep -E "^(SECRET|ENCRYPTION)_KEY=" /var/www/CamMatrix/backend/.env

# 2. Login admin + add kamera baru via API → cek password ke-encrypt dengan key baru
# (kalau berhasil decrypt + show stream, rotation OK)

# 3. Ambil ciphertext password kamera lama, coba decrypt manual dengan SECRET_KEY (LAMA)
# Harus FAIL (key sudah di-rotate)
sudo -u postgres psql cctv_vms -c "SELECT password FROM cameras WHERE id=16;"
# Lalu di Python:
python3 -c "
import os, hashlib, base64
from cryptography.fernet import Fernet
with open('/var/www/CamMatrix/backend/.env') as f:
    for line in f:
        if line.startswith('SECRET_KEY='):
            sk = line.split('=', 1)[1].strip()
key = base64.urlsafe_b64encode(hashlib.sha256(sk.encode()).digest())
ct = '<paste ciphertext from psql>'
try:
    print(Fernet(key).decrypt(ct.encode()))
    print('DECRYPT WITH SECRET_KEY SUCCEEDED — rotation belum sukses')
except Exception:
    print('DECRYPT WITH SECRET_KEY FAILED — rotation sukses (data sekarang only readable via ENCRYPTION_KEY)')
"
```

## Catatan untuk install_all.sh deployment baru

Kalau install fresh server, `install_all.sh` perlu generate ENCRYPTION_KEY juga. Patch belum di-include di module ini — magang harus tambah manual:

```bash
# Tambahkan di install_all.sh, setelah JWT_SECRET=$(openssl rand -hex 32):
ENCRYPTION_KEY=$(openssl rand -hex 32)

# Lalu di cat << EOF > $APP_DIR/backend/.env block:
SECRET_KEY=${JWT_SECRET}
ENCRYPTION_KEY=${ENCRYPTION_KEY}        # ← TAMBAH BARIS INI
DATABASE_URL=...
```

## Rollback (kalau perlu)

```bash
ls -lt /var/backups/cammatrix-fix-p5/{config,security}.py.bak-* /var/backups/cammatrix-fix-p5/.env.bak-* | head -3

# Restore code
sudo cp /var/backups/cammatrix-fix-p5/config.py.bak-<TS> /var/www/CamMatrix/backend/app/core/config.py
sudo cp /var/backups/cammatrix-fix-p5/security.py.bak-<TS> /var/www/CamMatrix/backend/app/core/security.py

# ⚠️ DATA: rollback security.py SAJA tanpa rotate balik = ciphertext sekarang
# ter-encrypt dengan ENCRYPTION_KEY tapi code coba decrypt pakai SECRET_KEY → fail.
# Untuk rollback penuh, run rotation reverse dulu (script tidak provide ini —
# manual dengan adapt rotate_encryption_key.py: tukar fernet_old & fernet_new).

sudo systemctl restart cammatrix-backend
```

Lebih baik **jangan rollback Module 05** kecuali ada bug serius. Key separation = improvement permanen.
