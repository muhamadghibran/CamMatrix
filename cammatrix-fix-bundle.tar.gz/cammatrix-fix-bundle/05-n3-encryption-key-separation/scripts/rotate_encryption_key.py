"""
Rotate Fernet encryption key — re-encrypt password kamera dari SECRET_KEY-derived
ke ENCRYPTION_KEY-derived.

Run SEKALI saja saat migrasi N3:
  cd /var/www/CamMatrix/backend
  sudo -u <backend_user> ./venv/bin/python -m scripts.rotate_encryption_key

Prereq:
- ENCRYPTION_KEY sudah ditambahkan ke .env
- Backend BELUM di-restart dengan config.py + security.py baru (jadi data lama
  masih bisa di-decrypt dengan SHA256(SECRET_KEY) lama)

Script ini:
1. Baca SECRET_KEY + ENCRYPTION_KEY dari env
2. Build 2 Fernet: old (dari SECRET_KEY) dan new (dari ENCRYPTION_KEY)
3. Loop semua row Camera dengan password != NULL
4. Decrypt dengan old → encrypt dengan new → UPDATE
5. Print stats

SAFE TO RUN MULTIPLE TIMES — kalau row sudah pakai key baru, decrypt dengan
old akan fail, script skip dan lanjut.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import sys

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import select

# Pastikan PYTHONPATH benar
sys.path.insert(0, "/var/www/CamMatrix/backend")

from app.core.database import AsyncSessionLocal  # noqa: E402
from app.models.camera import Camera  # noqa: E402


def _make_fernet(seed: str) -> Fernet:
    digest = hashlib.sha256(seed.encode()).digest()
    return Fernet(base64.urlsafe_b64encode(digest))


async def rotate() -> None:
    secret_key = os.environ.get("SECRET_KEY")
    encryption_key = os.environ.get("ENCRYPTION_KEY")

    if not secret_key:
        print("ERROR: SECRET_KEY env var kosong.", file=sys.stderr)
        sys.exit(1)
    if not encryption_key:
        print("ERROR: ENCRYPTION_KEY env var kosong. Generate dulu.", file=sys.stderr)
        sys.exit(1)
    if encryption_key == secret_key:
        print("ERROR: ENCRYPTION_KEY tidak boleh sama dengan SECRET_KEY.", file=sys.stderr)
        sys.exit(1)

    fernet_old = _make_fernet(secret_key)
    fernet_new = _make_fernet(encryption_key)

    rotated = 0
    skipped_already_new = 0
    skipped_invalid = 0
    total = 0

    async with AsyncSessionLocal() as db:
        cameras = (await db.execute(select(Camera))).scalars().all()

        for cam in cameras:
            total += 1
            if not cam.password:
                continue

            # Coba decrypt dengan key lama
            try:
                plain = fernet_old.decrypt(cam.password.encode()).decode()
            except InvalidToken:
                # Bukan ciphertext key lama. Coba key baru — kalau berhasil,
                # row ini sudah migrated, skip.
                try:
                    fernet_new.decrypt(cam.password.encode())
                    skipped_already_new += 1
                    continue
                except InvalidToken:
                    print(f"  ⚠ camera id={cam.id} password tidak bisa di-decrypt "
                          f"dengan key lama maupun baru — SKIP")
                    skipped_invalid += 1
                    continue

            # Re-encrypt dengan key baru
            cam.password = fernet_new.encrypt(plain.encode()).decode()
            db.add(cam)
            rotated += 1

        await db.commit()

    print(f"\n=== Rotation summary ===")
    print(f"Total cameras                      : {total}")
    print(f"Successfully rotated                : {rotated}")
    print(f"Already using new key (skipped)     : {skipped_already_new}")
    print(f"Invalid ciphertext (skipped, manual): {skipped_invalid}")
    print(f"\nSemua password kamera sekarang ter-encrypt dengan ENCRYPTION_KEY.")
    print(f"Sekarang aman restart backend dengan code N3-fixed.")


if __name__ == "__main__":
    asyncio.run(rotate())
