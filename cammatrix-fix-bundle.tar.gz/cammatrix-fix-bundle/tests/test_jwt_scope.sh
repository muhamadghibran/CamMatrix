#!/bin/bash
# Test P4 JWT scope enforcement
# Verifikasi: token dengan scope=password_change_only TIDAK boleh hit /cameras
set -uo pipefail

API="${API:-http://127.0.0.1:8000/api/v1}"
GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

if [ -z "${ADMIN_EMAIL:-}" ]; then read -p "Admin email: " ADMIN_EMAIL; fi
if [ -z "${ADMIN_PASSWORD:-}" ]; then read -s -p "Admin password: " ADMIN_PASSWORD; echo; fi

echo "=== 1. Login normal — dapat token full-scope ==="
RESP=$(curl -sS -X POST "$API/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "username=$ADMIN_EMAIL" --data-urlencode "password=$ADMIN_PASSWORD")
TOKEN=$(echo "$RESP" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("access_token",""))')
[ -n "$TOKEN" ] || { echo -e "${RED}Login gagal${NC}"; echo "$RESP"; exit 1; }
echo -e "${GREEN}OK: token len ${#TOKEN}${NC}"

echo
echo "=== 2. GET /cameras — harus 200 (token full-scope) ==="
CODE=$(curl -sS -o /dev/null -w "%{http_code}" -L -H "Authorization: Bearer $TOKEN" "$API/cameras/")
if [ "$CODE" = "200" ]; then echo -e "${GREEN}OK: HTTP $CODE${NC}"; else echo -e "${RED}FAIL: HTTP $CODE${NC}"; fi

echo
echo "=== 3. Set must_change_password=true → re-login → token scope-limited ==="
echo "Skip langkah 3-5 jika belum ada user dengan must_change_password kolom + endpoint /change-password."
echo "Test manual:"
echo "  - sudo -u postgres psql cctv_vms -c \"UPDATE users SET must_change_password=true WHERE email='$ADMIN_EMAIL';\""
echo "  - login ulang via curl di atas → response harus berisi must_change_password:true"
echo "  - decode JWT (https://jwt.io) → claim 'scope' harus 'password_change_only'"
echo "  - GET /cameras dengan token scope-limited → harus HTTP 403 'Password change required'"
echo "  - PUT /auth/change-password dengan token scope-limited → harus 200 (boleh akses)"
echo "  - GET /me dengan token scope-limited → harus 200 (boleh akses)"
echo
echo "Reset:"
echo "  - sudo -u postgres psql cctv_vms -c \"UPDATE users SET must_change_password=false WHERE email='$ADMIN_EMAIL';\""
