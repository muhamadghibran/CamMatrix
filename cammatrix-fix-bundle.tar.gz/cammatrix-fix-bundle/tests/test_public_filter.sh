#!/bin/bash
# Test N1 public filter
set -uo pipefail

API="${API:-http://127.0.0.1:8000/api/v1}"
GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

echo "=== Public cameras endpoint (no auth) ==="
RESP=$(curl -sS "$API/public/cameras")
COUNT=$(echo "$RESP" | python3 -c 'import sys,json;print(len(json.load(sys.stdin)))' 2>/dev/null || echo "ERR")
echo "Count: $COUNT"

if [ "$COUNT" = "0" ]; then
    echo -e "${GREEN}OK: default-deny working — semua kamera default is_public=false${NC}"
elif [ "$COUNT" = "ERR" ]; then
    echo -e "${RED}FAIL: response tidak parseable${NC}"
    echo "$RESP"
    exit 1
else
    echo -e "${GREEN}$COUNT kamera publik:${NC}"
    echo "$RESP" | python3 -m json.tool
fi

echo
echo "=== DB cameras (compare) ==="
TOTAL=$(sudo -u postgres psql cctv_vms -tAc "SELECT count(*) FROM cameras;" 2>/dev/null || echo "?")
PUBLIC=$(sudo -u postgres psql cctv_vms -tAc "SELECT count(*) FROM cameras WHERE is_public=true;" 2>/dev/null || echo "?")
echo "Total cameras: $TOTAL"
echo "is_public=true: $PUBLIC"

if [ "$COUNT" = "$PUBLIC" ]; then
    echo -e "${GREEN}OK: count match${NC}"
else
    echo -e "${RED}FAIL: API count ($COUNT) ≠ DB count is_public=true ($PUBLIC)${NC}"
fi
